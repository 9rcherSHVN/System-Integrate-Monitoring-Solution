[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string] $IngestionEndpoint,

    [Parameter(Mandatory)]
    [string] $DcrImmutableId,

    [string] $StreamName = 'Custom-ServiceAccountStatus',

    [switch] $IncludeScheduledTasks,

    [switch] $IncludeIisApplicationPools
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Import-Module "$PSScriptRoot\AzureMonitorIngestion.psm1" -Force
Import-Module ActiveDirectory -ErrorAction Stop

function Test-BuiltInServiceIdentity {
    param([string] $AccountName)

    $normalized = $AccountName.Trim().ToUpperInvariant()

    return $normalized -in @(
        'LOCALSYSTEM',
        'NT AUTHORITY\SYSTEM',
        'NT AUTHORITY\LOCALSERVICE',
        'NT AUTHORITY\NETWORKSERVICE',
        'NT SERVICE\ALL SERVICES'
    ) -or $normalized.StartsWith('NT SERVICE\') `
       -or $normalized.StartsWith('IIS APPPOOL\')
}

function Get-NormalizedSamAccountName {
    param([string] $AccountName)

    if ($AccountName -match '^[^\\]+\\(.+)$') {
        return $Matches[1]
    }

    if ($AccountName -match '^([^@]+)@') {
        return $Matches[1]
    }

    return $AccountName
}

function Convert-AdFileTime {
    param($Value)

    if ($null -eq $Value) {
        return $null
    }

    $numericValue = [Int64]$Value

    if ($numericValue -le 0 -or $numericValue -eq [Int64]::MaxValue) {
        return $null
    }

    return [DateTime]::FromFileTimeUtc($numericValue)
}

function Resolve-DirectoryAccount {
    param(
        [Parameter(Mandatory)]
        [string] $AccountName
    )

    if (Test-BuiltInServiceIdentity -AccountName $AccountName) {
        return [pscustomobject]@{
            AccountType       = 'BuiltInOrVirtual'
            SamAccountName    = $AccountName
            DistinguishedName = $null
            Enabled           = $true
            LockedOut         = $false
            PasswordLastSet   = $null
            PasswordExpires   = $null
            DaysUntilExpiry   = $null
            PasswordNeverExpires = $true
            ManagedPassword   = $true
            ResolutionStatus  = 'NotApplicable'
        }
    }

    $sam = Get-NormalizedSamAccountName -AccountName $AccountName

    if ($sam.EndsWith('$')) {
        try {
            $gmsa = Get-ADServiceAccount `
                -Identity $sam `
                -Properties Enabled, DistinguishedName `
                -ErrorAction Stop

            return [pscustomobject]@{
                AccountType       = 'gMSA'
                SamAccountName    = $gmsa.SamAccountName
                DistinguishedName = $gmsa.DistinguishedName
                Enabled           = [bool]$gmsa.Enabled
                LockedOut         = $false
                PasswordLastSet   = $null
                PasswordExpires   = $null
                DaysUntilExpiry   = $null
                PasswordNeverExpires = $true
                ManagedPassword   = $true
                ResolutionStatus  = 'Resolved'
            }
        }
        catch {
            # A trailing dollar sign can also represent a computer account.
        }
    }

    try {
        $user = Get-ADUser `
            -Identity $sam `
            -Properties @(
                'Enabled',
                'LockedOut',
                'PasswordLastSet',
                'PasswordNeverExpires',
                'msDS-UserPasswordExpiryTimeComputed',
                'DistinguishedName'
            ) `
            -ErrorAction Stop

        $expiry = Convert-AdFileTime `
            -Value $user.'msDS-UserPasswordExpiryTimeComputed'

        $daysUntilExpiry = $null

        if ($expiry) {
            $daysUntilExpiry = [Math]::Floor(
                ($expiry - (Get-Date).ToUniversalTime()).TotalDays
            )
        }

        return [pscustomobject]@{
            AccountType       = 'DomainUser'
            SamAccountName    = $user.SamAccountName
            DistinguishedName = $user.DistinguishedName
            Enabled           = [bool]$user.Enabled
            LockedOut         = [bool]$user.LockedOut
            PasswordLastSet   = if ($user.PasswordLastSet) {
                $user.PasswordLastSet.ToUniversalTime().ToString('o')
            } else {
                $null
            }
            PasswordExpires   = if ($expiry) {
                $expiry.ToString('o')
            } else {
                $null
            }
            DaysUntilExpiry   = $daysUntilExpiry
            PasswordNeverExpires = [bool]$user.PasswordNeverExpires
            ManagedPassword   = $false
            ResolutionStatus  = 'Resolved'
        }
    }
    catch {
        return [pscustomobject]@{
            AccountType       = 'UnknownOrLocal'
            SamAccountName    = $sam
            DistinguishedName = $null
            Enabled           = $null
            LockedOut         = $null
            PasswordLastSet   = $null
            PasswordExpires   = $null
            DaysUntilExpiry   = $null
            PasswordNeverExpires = $null
            ManagedPassword   = $false
            ResolutionStatus  = 'NotResolved'
        }
    }
}

$references = [System.Collections.Generic.List[object]]::new()

foreach ($service in Get-CimInstance -ClassName Win32_Service) {
    if ([string]::IsNullOrWhiteSpace($service.StartName)) {
        continue
    }

    $references.Add([pscustomobject]@{
        UsageType   = 'WindowsService'
        UsageName   = $service.Name
        DisplayName = $service.DisplayName
        AccountName = $service.StartName
    })
}

if ($IncludeScheduledTasks) {
    foreach ($task in Get-ScheduledTask) {
        $account = $task.Principal.UserId

        if ([string]::IsNullOrWhiteSpace($account)) {
            continue
        }

        $references.Add([pscustomobject]@{
            UsageType   = 'ScheduledTask'
            UsageName   = "$($task.TaskPath)$($task.TaskName)"
            DisplayName = $task.TaskName
            AccountName = $account
        })
    }
}

if ($IncludeIisApplicationPools) {
    if (Get-Module -ListAvailable -Name WebAdministration) {
        Import-Module WebAdministration -ErrorAction Stop

        foreach ($appPool in Get-ChildItem IIS:\AppPools) {
            $identityType = [string]$appPool.processModel.identityType
            $account = [string]$appPool.processModel.userName

            if ([string]::IsNullOrWhiteSpace($account)) {
                $account = "IIS APPPOOL\$($appPool.Name) [$identityType]"
            }

            $references.Add([pscustomobject]@{
                UsageType   = 'IISApplicationPool'
                UsageName   = $appPool.Name
                DisplayName = $appPool.Name
                AccountName = $account
            })
        }
    }
}

$collectionTime = (Get-Date).ToUniversalTime().ToString('o')
$records = [System.Collections.Generic.List[object]]::new()
$resolutionCache = @{}

foreach ($reference in $references) {
    if (-not $resolutionCache.ContainsKey($reference.AccountName)) {
        $resolutionCache[$reference.AccountName] =
            Resolve-DirectoryAccount -AccountName $reference.AccountName
    }

    $identity = $resolutionCache[$reference.AccountName]

    $records.Add([pscustomobject]@{
        TimeGenerated        = $collectionTime
        Computer             = $env:COMPUTERNAME
        UsageType            = $reference.UsageType
        UsageName            = $reference.UsageName
        DisplayName          = $reference.DisplayName
        ConfiguredAccount    = $reference.AccountName
        AccountType          = $identity.AccountType
        SamAccountName       = $identity.SamAccountName
        DistinguishedName    = $identity.DistinguishedName
        Enabled              = $identity.Enabled
        LockedOut            = $identity.LockedOut
        PasswordLastSet      = $identity.PasswordLastSet
        PasswordExpires      = $identity.PasswordExpires
        DaysUntilExpiry      = $identity.DaysUntilExpiry
        PasswordNeverExpires = $identity.PasswordNeverExpires
        ManagedPassword      = $identity.ManagedPassword
        ResolutionStatus     = $identity.ResolutionStatus
        CollectorVersion     = '1.0.0'
    })
}

Send-AzureMonitorRecords `
    -Endpoint $IngestionEndpoint `
    -DcrImmutableId $DcrImmutableId `
    -StreamName $StreamName `
    -Records $records.ToArray()

Write-Output "Submitted $($records.Count) service-account status records."