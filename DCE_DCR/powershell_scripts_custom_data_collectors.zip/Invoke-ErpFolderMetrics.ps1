$folders = @(
    @{
        Application = 'ERP'
        Path        = 'D:\ERP\Logs'
    },
    @{
        Application = 'ERP-IIS'
        Path        = 'D:\IISLogs'
    },
    @{
        Application = 'Middleware'
        Path        = 'E:\Middleware\MessageArchive'
    }
)

.\Collect-ErpFolderMetrics.ps1 `
    -FolderDefinitions $folders `
    -RetentionDays 30 `
    -IngestionEndpoint 'https://<dce-or-dcr-ingestion-endpoint>' `
    -DcrImmutableId 'dcr-00000000000000000000000000000000' `
    -StreamName 'Custom-ErpFolderMetrics'