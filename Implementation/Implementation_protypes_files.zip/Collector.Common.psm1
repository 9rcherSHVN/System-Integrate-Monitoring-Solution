Set-StrictMode -Version Latest

function Read-CollectorConfiguration {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string] $Path
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Configuration file was not found: $Path"
    }

    try {
        return Get-Content -LiteralPath $Path -Raw -Encoding UTF8 |
            ConvertFrom-Json -ErrorAction Stop
    }
    catch {
        throw "Configuration file is invalid JSON: $Path. $($_.Exception.Message)"
    }
}

function New-CollectorHealthRecord {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string] $CollectorName,

        [Parameter(Mandatory)]
        [string] $ExecutionId,

        [Parameter(Mandatory)]
        [datetime] $StartedUtc,

        [Parameter(Mandatory)]
        [ValidateSet('Success', 'PartialSuccess', 'Failed')]
        [string] $Status,

        [long] $RecordsCollected = 0,

        [long] $RecordsSubmitted = 0,

        [string] $TargetScope,

        [string] $ErrorCode,

        [string] $ErrorMessage,

        [string] $CollectorVersion = '1.0.0'
    )

    $completedUtc = (Get-Date).ToUniversalTime()

    return [pscustomobject]@{
        TimeGenerated     = $completedUtc.ToString('o')
        CollectorName     = $CollectorName
        Computer          = $env:COMPUTERNAME
        TargetScope       = $TargetScope
        ExecutionId       = $ExecutionId
        RecordsCollected  = $RecordsCollected
        RecordsSubmitted  = $RecordsSubmitted
        DurationSeconds   = [Math]::Round(
            ($completedUtc - $StartedUtc).TotalSeconds,
            3
        )
        Status            = $Status
        ErrorCode         = $ErrorCode
        ErrorMessage      = $ErrorMessage
        CollectorVersion  = $CollectorVersion
    }
}

Export-ModuleMember -Function Read-CollectorConfiguration, New-CollectorHealthRecord