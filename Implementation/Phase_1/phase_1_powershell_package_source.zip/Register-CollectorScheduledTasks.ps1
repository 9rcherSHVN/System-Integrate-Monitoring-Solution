[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string] $CollectorRunAsAccount,

    [Parameter(Mandatory)]
    [SecureString] $CollectorRunAsPassword,

    [string] $CollectorRoot = 'C:\ProgramData\Contoso\AzureMonitorCollectors',

    [ValidateRange(5, 1440)]
    [int] $FolderMetricsIntervalMinutes = 60
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$currentPath = Join-Path $CollectorRoot 'Current'
$collectorPath = Join-Path $currentPath 'Collectors'
$powerShell = 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'

if (-not (Test-Path -LiteralPath $collectorPath)) {
    throw "Collector package was not found at: $collectorPath"
}

function Register-CollectorTask {
    param(
        [Parameter(Mandatory)]
        [string] $TaskName,

        [Parameter(Mandatory)]
        [string] $ScriptPath,

        [Parameter(Mandatory)]
        [Microsoft.Management.Infrastructure.CimInstance[]] $Triggers,

        [Parameter(Mandatory)]
        [string] $Description
    )

    $action = New-ScheduledTaskAction `
        -Execute $powerShell `
        -Argument (
            '-NoLogo -NoProfile -NonInteractive -ExecutionPolicy AllSigned ' +
            "-File `"$ScriptPath`""
        ) `
        -WorkingDirectory $currentPath

    $settings = New-ScheduledTaskSettingsSet `
        -ExecutionTimeLimit (New-TimeSpan -Minutes 30) `
        -MultipleInstances IgnoreNew `
        -RestartCount 3 `
        -RestartInterval (New-TimeSpan -Minutes 15) `
        -StartWhenAvailable

    Register-ScheduledTask `
        -TaskName $TaskName `
        -Action $action `
        -Trigger $Triggers `
        -Settings $settings `
        -User $CollectorRunAsAccount `
        -Password (
            [Runtime.InteropServices.Marshal]::PtrToStringBSTR(
                [Runtime.InteropServices.Marshal]::SecureStringToBSTR(
                    $CollectorRunAsPassword
                )
            )
        ) `
        -RunLevel Limited `
        -Description $Description `
        -Force | Out-Null
}

$certificateScript = Join-Path $collectorPath 'Collect-CertificateInventory.ps1'
$folderScript = Join-Path $collectorPath 'Collect-ErpFolderMetrics.ps1'
$spoolScript = Join-Path $collectorPath 'Submit-CollectorSpool.ps1'

$certificateTrigger = New-ScheduledTaskTrigger -Daily -At 2:15AM

$folderTrigger = New-ScheduledTaskTrigger -Once -At (Get-Date).Date.AddMinutes(30)
$folderTrigger.Repetition.Interval = (New-TimeSpan -Minutes $FolderMetricsIntervalMinutes)
$folderTrigger.Repetition.Duration = (New-TimeSpan -Days 1)

$certificateSpoolAction = New-ScheduledTaskAction `
    -Execute $powerShell `
    -Argument (
        '-NoLogo -NoProfile -NonInteractive -ExecutionPolicy AllSigned ' +
        "-File `"$spoolScript`" -CollectorName CertificateInventory"
    ) `
    -WorkingDirectory $currentPath

$folderSpoolAction = New-ScheduledTaskAction `
    -Execute $powerShell `
    -Argument (
        '-NoLogo -NoProfile -NonInteractive -ExecutionPolicy AllSigned ' +
        "-File `"$spoolScript`" -CollectorName ErpFolderMetrics"
    ) `
    -WorkingDirectory $currentPath

$spoolTrigger = New-ScheduledTaskTrigger -Once -At (Get-Date).Date.AddMinutes(10)
$spoolTrigger.Repetition.Interval = (New-TimeSpan -Minutes 15)
$spoolTrigger.Repetition.Duration = (New-TimeSpan -Days 1)

$settings = New-ScheduledTaskSettingsSet `
    -ExecutionTimeLimit (New-TimeSpan -Minutes 30) `
    -MultipleInstances IgnoreNew `
    -RestartCount 2 `
    -RestartInterval (New-TimeSpan -Minutes 15) `
    -StartWhenAvailable

Register-CollectorTask `
    -TaskName 'Contoso-Monitor-CertificateInventory' `
    -ScriptPath $certificateScript `
    -Triggers @($certificateTrigger) `
    -Description 'Collects WebHosting certificate inventory for Azure Monitor.'

Register-CollectorTask `
    -TaskName 'Contoso-Monitor-ErpFolderMetrics' `
    -ScriptPath $folderScript `
    -Triggers @($folderTrigger) `
    -Description 'Collects ERP log-directory metrics for Azure Monitor.'

Register-ScheduledTask `
    -TaskName 'Contoso-Monitor-CertificateInventory-SpoolReplay' `
    -Action $certificateSpoolAction `
    -Trigger $spoolTrigger `
    -Settings $settings `
    -User $CollectorRunAsAccount `
    -Password (
        [Runtime.InteropServices.Marshal]::PtrToStringBSTR(
            [Runtime.InteropServices.Marshal]::SecureStringToBSTR(
                $CollectorRunAsPassword
            )
        )
    ) `
    -RunLevel Limited `
    -Description 'Replays spooled certificate telemetry to Azure Monitor.' `
    -Force | Out-Null

Register-ScheduledTask `
    -TaskName 'Contoso-Monitor-ErpFolderMetrics-SpoolReplay' `
    -Action $folderSpoolAction `
    -Trigger $spoolTrigger `
    -Settings $settings `
    -User $CollectorRunAsAccount `
    -Password (
        [Runtime.InteropServices.Marshal]::PtrToStringBSTR(
            [Runtime.InteropServices.Marshal]::SecureStringToBSTR(
                $CollectorRunAsPassword
            )
        )
    ) `
    -RunLevel Limited `
    -Description 'Replays spooled ERP folder telemetry to Azure Monitor.' `
    -Force | Out-Null

Write-Output 'Collector scheduled tasks were registered successfully.'