param windowsDiskMetricsDcrName = 'dcr-erpmon-windows-disk-custom-pilot-001'

param windowsDiskMetricsCollectorPrincipalIds = [
  '00000000-0000-0000-0000-000000000002'
]