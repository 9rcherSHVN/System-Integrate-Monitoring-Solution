[CmdletBinding()]
param(
    [string[]] $CertificateStores = @(
        'Cert:\LocalMachine\My',
        'Cert:\LocalMachine\WebHosting'
    ),

    [Parameter(Mandatory)]
    [string] $IngestionEndpoint,

    [Parameter(Mandatory)]
    [string] $DcrImmutableId,

    [string] $StreamName = 'Custom-ServerCertificateInventory'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Import-Module "$PSScriptRoot\AzureMonitorIngestion.psm1" -Force

function Get-CertificateDnsNames {
    param(
        [Parameter(Mandatory)]
        [System.Security.Cryptography.X509Certificates.X509Certificate2] $Certificate
    )

    $names = [System.Collections.Generic.List[string]]::new()

    if ($Certificate.PSObject.Properties.Name -contains 'DnsNameList') {
        foreach ($dnsName in $Certificate.DnsNameList) {
            if ($dnsName.Unicode) {
                $names.Add([string]$dnsName.Unicode)
            }
        }
    }

    return ($names | Sort-Object -Unique) -join ';'
}

function Get-IisCertificateBindingMap {
    $map = @{}

    if (-not (Get-Module -ListAvailable -Name WebAdministration)) {
        return $map
    }

    Import-Module WebAdministration -ErrorAction Stop

    foreach ($site in Get-Website) {
        foreach ($binding in Get-WebBinding -Name $site.Name -Protocol https) {
            $hash = $binding.certificateHash

            if ($hash -is [byte[]]) {
                $thumbprint = ([BitConverter]::ToString($hash)).Replace('-', '')
            }
            else {
                $thumbprint = ([string]$hash).Replace(' ', '').ToUpperInvariant()
            }

            if ([string]::IsNullOrWhiteSpace($thumbprint)) {
                continue
            }

            $description = '{0}|{1}|{2}' -f `
                $site.Name,
                $binding.bindingInformation,
                $binding.certificateStoreName

            if (-not $map.ContainsKey($thumbprint)) {
                $map[$thumbprint] = [System.Collections.Generic.List[string]]::new()
            }

            $map[$thumbprint].Add($description)
        }
    }

    return $map
}

$collectionTime = (Get-Date).ToUniversalTime()
$iisBindings = @{}

try {
    $iisBindings = Get-IisCertificateBindingMap
}
catch {
    Write-Warning "IIS binding discovery failed: $($_.Exception.Message)"
}

$records = [System.Collections.Generic.List[object]]::new()

foreach ($storePath in $CertificateStores) {
    if (-not (Test-Path -LiteralPath $storePath)) {
        $records.Add([pscustomobject]@{
            TimeGenerated   = $collectionTime.ToString('o')
            Computer        = $env:COMPUTERNAME
            StoreLocation   = 'LocalMachine'
            StoreName       = Split-Path $storePath -Leaf
            Subject         = $null
            DnsNames        = $null
            Issuer          = $null
            Thumbprint      = $null
            SerialNumber    = $null
            NotBefore       = $null
            NotAfter        = $null
            DaysUntilExpiry = $null
            HasPrivateKey   = $null
            EnhancedKeyUsage = $null
            IisBindings     = $null
            CollectionStatus = 'StoreNotFound'
            CollectorVersion = '1.0.0'
        })

        continue
    }

    foreach ($certificate in Get-ChildItem -LiteralPath $storePath -ErrorAction Stop) {
        $thumbprint = $certificate.Thumbprint.Replace(' ', '').ToUpperInvariant()
        $bindingList = $null

        if ($iisBindings.ContainsKey($thumbprint)) {
            $bindingList = ($iisBindings[$thumbprint] | Sort-Object -Unique) -join ';'
        }

        $eku = @(
            foreach ($usage in $certificate.EnhancedKeyUsageList) {
                if ($usage.FriendlyName) {
                    $usage.FriendlyName
                }
                else {
                    $usage.ObjectId.Value
                }
            }
        ) -join ';'

        $records.Add([pscustomobject]@{
            TimeGenerated    = $collectionTime.ToString('o')
            Computer         = $env:COMPUTERNAME
            StoreLocation    = 'LocalMachine'
            StoreName        = Split-Path $storePath -Leaf
            Subject          = $certificate.Subject
            DnsNames         = Get-CertificateDnsNames -Certificate $certificate
            Issuer           = $certificate.Issuer
            Thumbprint       = $thumbprint
            SerialNumber     = $certificate.SerialNumber
            NotBefore        = $certificate.NotBefore.ToUniversalTime().ToString('o')
            NotAfter         = $certificate.NotAfter.ToUniversalTime().ToString('o')
            DaysUntilExpiry  = [Math]::Floor(
                ($certificate.NotAfter.ToUniversalTime() - $collectionTime).TotalDays
            )
            HasPrivateKey    = [bool]$certificate.HasPrivateKey
            EnhancedKeyUsage = $eku
            IisBindings      = $bindingList
            CollectionStatus = 'Success'
            CollectorVersion = '1.0.0'
        })
    }
}

Send-AzureMonitorRecords `
    -Endpoint $IngestionEndpoint `
    -DcrImmutableId $DcrImmutableId `
    -StreamName $StreamName `
    -Records $records.ToArray()

Write-Output "Submitted $($records.Count) certificate inventory records."