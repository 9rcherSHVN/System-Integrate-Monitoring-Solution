@description('Certificate DCR resource ID.')
param certificateDcrResourceId string

@description('Folder metrics DCR resource ID.')
param folderMetricsDcrResourceId string

@description('Collector health DCR resource ID.')
param collectorHealthDcrResourceId string

@description('Azure Arc managed identity principal IDs for certificate collector hosts.')
param certificateCollectorPrincipalIds array

@description('Azure Arc managed identity principal IDs for ERP folder collector hosts.')
param folderCollectorPrincipalIds array

@description('Azure Arc managed identity principal IDs for collector-health submitters.')
param healthCollectorPrincipalIds array

// Built-in role: Monitoring Metrics Publisher
var monitoringMetricsPublisherRoleDefinitionId = subscriptionResourceId(
  'Microsoft.Authorization/roleDefinitions'
  '3913510d-42f4-4e42-8a64-420c390055eb'
)

resource certificateDcrRoleAssignments 'Microsoft.Authorization/roleAssignments@2022-04-01' = [
  for principalId in certificateCollectorPrincipalIds: {
    name: guid(
      certificateDcrResourceId
      principalId
      monitoringMetricsPublisherRoleDefinitionId
    )
    scope: resourceId(
      'Microsoft.Insights/dataCollectionRules'
      last(split(certificateDcrResourceId, '/'))
    )
    properties: {
      roleDefinitionId: monitoringMetricsPublisherRoleDefinitionId
      principalId: principalId
      principalType: 'ServicePrincipal'
    }
  }
]

resource folderMetricsDcrRoleAssignments 'Microsoft.Authorization/roleAssignments@2022-04-01' = [
  for principalId in folderCollectorPrincipalIds: {
    name: guid(
      folderMetricsDcrResourceId
      principalId
      monitoringMetricsPublisherRoleDefinitionId
    )
    scope: resourceId(
      'Microsoft.Insights/dataCollectionRules'
      last(split(folderMetricsDcrResourceId, '/'))
    )
    properties: {
      roleDefinitionId: monitoringMetricsPublisherRoleDefinitionId
      principalId: principalId
      principalType: 'ServicePrincipal'
    }
  }
]

resource collectorHealthDcrRoleAssignments 'Microsoft.Authorization/roleAssignments@2022-04-01' = [
  for principalId in healthCollectorPrincipalIds: {
    name: guid(
      collectorHealthDcrResourceId
      principalId
      monitoringMetricsPublisherRoleDefinitionId
    )
    scope: resourceId(
      'Microsoft.Insights/dataCollectionRules'
      last(split(collectorHealthDcrResourceId, '/'))
    )
    properties: {
      roleDefinitionId: monitoringMetricsPublisherRoleDefinitionId
      principalId: principalId
      principalType: 'ServicePrincipal'
    }
  }
]