Set-StrictMode -Version Latest

function Enter-CollectorLock {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string] $LockPath
    )

    $lockDirectory = Split-Path -Path $LockPath -Parent

    if (-not (Test-Path -LiteralPath $lockDirectory)) {
        New-Item -Path $lockDirectory -ItemType Directory -Force | Out-Null
    }

    try {
        $stream = [System.IO.File]::Open(
            $LockPath,
            [System.IO.FileMode]::OpenOrCreate,
            [System.IO.FileAccess]::ReadWrite,
            [System.IO.FileShare]::None
        )

        return $stream
    }
    catch {
        throw "Collector lock is already held: $LockPath"
    }
}

function Exit-CollectorLock {
    [CmdletBinding()]
    param(
        [Parameter()]
        [System.IO.FileStream] $LockHandle,

        [Parameter(Mandatory)]
        [string] $LockPath
    )

    if ($LockHandle) {
        $LockHandle.Dispose()
    }

    if (Test-Path -LiteralPath $LockPath) {
        Remove-Item -LiteralPath $LockPath -Force -ErrorAction SilentlyContinue
    }
}

Export-ModuleMember -Function Enter-CollectorLock, Exit-CollectorLock