Set-StrictMode -Version Latest

function Write-CollectorLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string] $LogDirectory,

        [Parameter(Mandatory)]
        [ValidateSet('Debug', 'Information', 'Warning', 'Error')]
        [string] $Level,

        [Parameter(Mandatory)]
        [string] $Message,

        [string] $ExecutionId
    )

    if (-not (Test-Path -LiteralPath $LogDirectory)) {
        New-Item -Path $LogDirectory -ItemType Directory -Force | Out-Null
    }

    $timestamp = (Get-Date).ToUniversalTime().ToString('o')
    $logFile = Join-Path $LogDirectory ("{0:yyyy-MM-dd}.log" -f (Get-Date))

    $record = [ordered]@{
        TimeGenerated = $timestamp
        Level         = $Level
        ExecutionId   = $ExecutionId
        Message       = $Message
    }

    # Keep messages sanitized: no tokens, passwords, private keys, or raw payloads.
    ($record | ConvertTo-Json -Compress) |
        Add-Content -LiteralPath $logFile -Encoding UTF8
}

Export-ModuleMember -Function Write-CollectorLog