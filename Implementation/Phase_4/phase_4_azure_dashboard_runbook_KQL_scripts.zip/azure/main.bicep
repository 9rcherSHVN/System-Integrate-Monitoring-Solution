@description('Enable deployment of the ERP disk and folder monitoring Workbook.')
param enableDiskAndFolderWorkbook bool = true

module diskAndFolderWorkbook './modules/certificate-workbook.bicep' = if (enableDiskAndFolderWorkbook) {
  name: 'deploy-disk-folder-workbook'
  params: {
    location: location
    workspaceResourceId: workspace.outputs.workspaceResourceId
    workbookDisplayName: 'ERP Disk and Log Folder Monitoring'
    workbookSerializedData: loadTextContent('../workbooks/disk-erp-folder-monitoring.workbook.json')
  }
  dependsOn: [
    tables
    windowsDiskPerformanceDcr
  ]
}