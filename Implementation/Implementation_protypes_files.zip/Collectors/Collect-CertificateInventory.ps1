[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$collectorRoot = Split-Path -Path $PSScriptRoot -Parent
$modulePath = Join-Path $collectorRoot 'Modules\AzureMonitorCollector.Common.psm1'
$configRoot = Join-Path $collectorRoot 'Config'

Import-Module $modulePath -Force

$sharedSettings = Read-CollectorJsonConfiguration `
    -Path (Join-Path $configRoot 'CollectorSettings.json')

$collectorSettings = Read-CollectorJsonConfiguration `
    -Path (Join-Path $configRoot 'CertificateInventory.config.json')

if (-not [bool]$collectorSettings.Enabled) {
    Write-Output 'Certificate collector is disabled by configuration.'
    exit 0
}

$collectorName = [string]$collectorSettings.CollectorName
$executionId = [guid]::NewGuid().ToString()
$startedUtc = (Get-Date).ToUniversalTime()
$logDirectory = Join-Path $sharedSettings.CollectorRoot "Logs\$collectorName"
$spoolDirectory = Join-Path $sharedSettings.CollectorRoot "Spool\$collectorName"
$lockPath = Join-Path $sharedSettings.CollectorRoot "Locks\$collectorName.lock"
$lockHandle = $null

$recordsCollected = 0
$recordsSubmitted = 0
$status = 'Success'
$errorCode = $null
$errorMessage = $null

function Get-CertificateDnsNames {
    param(
        [Parameter(Mandatory)]
        [System.Security.Cryptography.X509Certificates.X509Certificate2] $Certificate
    )

    if ($Certificate.PSObject.Properties.Name -notcontains 'DnsNameList') {
        return $null
    }

    $names = foreach ($dnsName in $Certificate.DnsNameList) {
        if ($dnsName.Unicode) {
            [string]$dnsName.Unicode
        }
    }

    return ($names | Sort-Object -Unique) -join ';'
}

function Get-IisBindingMap {
    $map = @{}

    if (-not [bool]$collectorSettings.EnableIisBindingDiscovery) {
        return $map
    }

    if (-not (Get-Module -ListAvailable -Name WebAdministration)) {
        Write-CollectorLog `
            -LogDirectory $logDirectory `
            -Level Warning `
            -ExecutionId $executionId `
            -Message (
                'IIS binding discovery is enabled but the WebAdministration module is unavailable.'
            )

        return $map
    }

    Import-Module WebAdministration -ErrorAction Stop

    foreach ($site in Get-Website) {
        foreach ($binding in Get-WebBinding -Name $site.Name -Protocol https) {
            $rawHash = $binding.certificateHash

            if ($rawHash -is [byte[]]) {
                $thumbprint = ([BitConverter]::ToString($rawHash)).Replace('-', '')
            }
            else {
                $thumbprint = ([string]$rawHash).Replace(' ', '').ToUpperInvariant()
            }

            if ([string]::IsNullOrWhiteSpace($thumbprint)) {
                continue
            }

            if (-not $map.ContainsKey($thumbprint)) {
                $map[$thumbprint] = [System.Collections.Generic.List[string]]::new()
            }

            $map[$thumbprint].Add((
                '{0}|{1}|{2}' -f
                $site.Name,
                $binding.bindingInformation,
                $binding.certificateStoreName
            ))
        }
    }

    return $map
}

try {
    $lockHandle = Enter-CollectorLock -LockPath $lockPath

    Write-CollectorLog `
        -LogDirectory $logDirectory `
        -Level Information `
        -ExecutionId $executionId `
        -Message 'Certificate inventory collection started.'

    Remove-CollectorExpiredFiles `
        -Directory $logDirectory `
        -RetentionDays ([int]$sharedSettings.Logging.RetentionDays)

    Remove-CollectorExpiredFiles `
        -Directory $spoolDirectory `
        -RetentionDays ([int]$sharedSettings.Ingestion.SpoolRetentionDays)

    Submit-CollectorSpoolBatches `
        -SpoolDirectory $spoolDirectory `
        -SharedSettings $sharedSettings `
        -LogDirectory $logDirectory `
        -ExecutionId $executionId | Out-Null

    $iisBindings = Get-IisBindingMap
    $collectionTime = (Get-Date).ToUniversalTime()
    $records = [System.Collections.Generic.List[object]]::new()

    foreach ($certificateStore in $collectorSettings.CertificateStores) {
        if (-not (Test-Path -LiteralPath $certificateStore)) {
            $status = 'PartialSuccess'

            $records.Add([pscustomobject]@{
                TimeGenerated     = $collectionTime.ToString('o')
                Computer          = $env:COMPUTERNAME
                Environment       = $sharedSettings.Environment
                Application       = $sharedSettings.Application
                StoreLocation     = 'LocalMachine'
                StoreName         = Split-Path -Path $certificateStore -Leaf
                Subject           = $null
                DnsNames          = $null
                Issuer            = $null
                Thumbprint        = $null
                SerialNumber      = $null
                NotBefore         = $null
                NotAfter          = $null
                DaysUntilExpiry   = $null
                HasPrivateKey     = $null
                EnhancedKeyUsage  = $null
                IisBindings       = $null
                CollectionStatus  = 'StoreNotFound'
                CollectorVersion  = '1.0.0'
            })

            continue
        }

        foreach ($certificate in Get-ChildItem -LiteralPath $certificateStore -ErrorAction Stop) {
            $thumbprint = $certificate.Thumbprint.Replace(' ', '').ToUpperInvariant()
            $bindingList = $null

            if ($iisBindings.ContainsKey($thumbprint)) {
                $bindingList = ($iisBindings[$thumbprint] | Sort-Object -Unique) -join ';'
            }

            $eku = @(
                foreach ($usage in $certificate.EnhancedKeyUsageList) {
                    if ($usage.FriendlyName) {
                        $usage.FriendlyName
                    }
                    else {
                        $usage.ObjectId.Value
                    }
                }
            ) -join ';'

            $records.Add([pscustomobject]@{
                TimeGenerated     = $collectionTime.ToString('o')
                Computer          = $env:COMPUTERNAME
                Environment       = $sharedSettings.Environment
                Application       = $sharedSettings.Application
                StoreLocation     = 'LocalMachine'
                StoreName         = Split-Path -Path $certificateStore -Leaf
                Subject           = $certificate.Subject
                DnsNames          = Get-CertificateDnsNames -Certificate $certificate
                Issuer            = $certificate.Issuer
                Thumbprint        = $thumbprint
                SerialNumber      = $certificate.SerialNumber
                NotBefore         = $certificate.NotBefore.ToUniversalTime().ToString('o')
                NotAfter          = $certificate.NotAfter.ToUniversalTime().ToString('o')
                DaysUntilExpiry   = [Math]::Floor(
                    ($certificate.NotAfter.ToUniversalTime() - $collectionTime).TotalDays
                )
                HasPrivateKey     = [bool]$certificate.HasPrivateKey
                EnhancedKeyUsage  = $eku
                IisBindings       = $bindingList
                CollectionStatus  = 'Success'
                CollectorVersion  = '1.0.0'
            })
        }
    }

    $recordsCollected = $records.Count

    $recordsSubmitted = Send-AzureMonitorRecords `
        -CollectorName $collectorName `
        -IngestionEndpoint $collectorSettings.IngestionEndpoint `
        -DcrImmutableId $collectorSettings.DcrImmutableId `
        -StreamName $collectorSettings.StreamName `
        -Records $records.ToArray() `
        -SharedSettings $sharedSettings `
        -SpoolDirectory $spoolDirectory `
        -LogDirectory $logDirectory `
        -ExecutionId $executionId

    Write-CollectorLog `
        -LogDirectory $logDirectory `
        -Level Information `
        -ExecutionId $executionId `
        -Message (
            "Certificate inventory completed. Collected=$recordsCollected; " +
            "submitted=$recordsSubmitted."
        )
}
catch {
    $status = 'Failed'
    $errorCode = 'CertificateCollectorFailure'
    $errorMessage = $_.Exception.Message

    Write-CollectorLog `
        -LogDirectory $logDirectory `
        -Level Error `
        -ExecutionId $executionId `
        -Message "Certificate collector failed. Error: $errorMessage"
}
finally {
    $healthRecord = New-CollectorHealthRecord `
        -CollectorName $collectorName `
        -ExecutionId $executionId `
        -StartedUtc $startedUtc `
        -Status $status `
        -RecordsCollected $recordsCollected `
        -RecordsSubmitted $recordsSubmitted `
        -TargetScope (($collectorSettings.CertificateStores) -join ';') `
        -ErrorCode $errorCode `
        -ErrorMessage $errorMessage `
        -CollectorVersion '1.0.0'

    try {
        Send-AzureMonitorRecords `
            -CollectorName $collectorName `
            -IngestionEndpoint $collectorSettings.HealthIngestionEndpoint `
            -DcrImmutableId $collectorSettings.HealthDcrImmutableId `
            -StreamName $collectorSettings.HealthStreamName `
            -Records @($healthRecord) `
            -SharedSettings $sharedSettings `
            -SpoolDirectory $spoolDirectory `
            -LogDirectory $logDirectory `
            -ExecutionId $executionId | Out-Null
    }
    catch {
        Write-CollectorLog `
            -LogDirectory $logDirectory `
            -Level Error `
            -ExecutionId $executionId `
            -Message (
                "Unable to submit collector-health record. Error: $($_.Exception.Message)"
            )
    }

    if ($lockHandle) {
        Exit-CollectorLock -LockHandle $lockHandle -LockPath $lockPath
    }
}

if ($status -eq 'Failed') {
    exit 1
}

exit 0