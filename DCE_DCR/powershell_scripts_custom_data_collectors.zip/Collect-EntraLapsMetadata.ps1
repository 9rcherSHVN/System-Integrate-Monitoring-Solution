[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string[]] $DeviceIds,

    [Parameter(Mandatory)]
    [string] $IngestionEndpoint,

    [Parameter(Mandatory)]
    [string] $DcrImmutableId,

    [string] $StreamName = 'Custom-LapsDeviceStatus'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Import-Module LAPS -ErrorAction Stop
Import-Module "$PSScriptRoot\AzureMonitorIngestion.psm1" -Force

$collectionTime = (Get-Date).ToUniversalTime()
$records = [System.Collections.Generic.List[object]]::new()

foreach ($deviceId in $DeviceIds) {
    try {
        # Deliberately omit any option that requests password values.
        $result = Get-LapsAADPassword -DeviceIds $deviceId -ErrorAction Stop

        foreach ($item in @($result)) {
            $expiry = $item.PasswordExpirationTime
            $backup = $item.BackupTimestamp
            $daysUntilExpiry = $null

            if ($expiry) {
                $daysUntilExpiry = [Math]::Floor(
                    (
                        ([DateTime]$expiry).ToUniversalTime() -
                        $collectionTime
                    ).TotalDays
                )
            }

            $records.Add([pscustomobject]@{
                TimeGenerated          = $collectionTime.ToString('o')
                DeviceId               = [string]$deviceId
                DeviceName             = [string]$item.DeviceName
                PasswordExpirationTime = if ($expiry) {
                    ([DateTime]$expiry).ToUniversalTime().ToString('o')
                } else {
                    $null
                }
                BackupTimestamp        = if ($backup) {
                    ([DateTime]$backup).ToUniversalTime().ToString('o')
                } else {
                    $null
                }
                DaysUntilExpiry        = $daysUntilExpiry
                BackupPresent          = [bool]$backup
                CollectionStatus       = 'Success'
                CollectorVersion       = '1.0.0'
            })
        }
    }
    catch {
        $records.Add([pscustomobject]@{
            TimeGenerated          = $collectionTime.ToString('o')
            DeviceId               = [string]$deviceId
            DeviceName             = $null
            PasswordExpirationTime = $null
            BackupTimestamp        = $null
            DaysUntilExpiry        = $null
            BackupPresent          = $false
            CollectionStatus       = "Error: $($_.Exception.Message)"
            CollectorVersion       = '1.0.0'
        })
    }
}

Send-AzureMonitorRecords `
    -Endpoint $IngestionEndpoint `
    -DcrImmutableId $DcrImmutableId `
    -StreamName $StreamName `
    -Records $records.ToArray()

Write-Output "Submitted $($records.Count) LAPS metadata records."