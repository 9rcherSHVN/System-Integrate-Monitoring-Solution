[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [ValidateSet('CertificateInventory', 'ErpFolderMetrics')]
    [string] $CollectorName
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$collectorRoot = Split-Path -Path $PSScriptRoot -Parent
$modulePath = Join-Path $collectorRoot 'Modules\AzureMonitorCollector.Common.psm1'
$configRoot = Join-Path $collectorRoot 'Config'

Import-Module $modulePath -Force

$sharedSettings = Read-CollectorJsonConfiguration `
    -Path (Join-Path $configRoot 'CollectorSettings.json')

$executionId = [guid]::NewGuid().ToString()
$logDirectory = Join-Path $sharedSettings.CollectorRoot "Logs\$CollectorName"
$spoolDirectory = Join-Path $sharedSettings.CollectorRoot "Spool\$CollectorName"
$lockPath = Join-Path $sharedSettings.CollectorRoot "Locks\$CollectorName-spool.lock"
$lockHandle = $null

try {
    $lockHandle = Enter-CollectorLock -LockPath $lockPath

    $replayed = Submit-CollectorSpoolBatches `
        -SpoolDirectory $spoolDirectory `
        -SharedSettings $sharedSettings `
        -LogDirectory $logDirectory `
        -ExecutionId $executionId

    Write-CollectorLog `
        -LogDirectory $logDirectory `
        -Level Information `
        -ExecutionId $executionId `
        -Message "Spool replay completed. Files replayed=$replayed."

    exit 0
}
catch {
    Write-CollectorLog `
        -LogDirectory $logDirectory `
        -Level Error `
        -ExecutionId $executionId `
        -Message "Spool replay failed. Error: $($_.Exception.Message)"

    exit 1
}
finally {
    if ($lockHandle) {
        Exit-CollectorLock -LockHandle $lockHandle -LockPath $lockPath
    }
}