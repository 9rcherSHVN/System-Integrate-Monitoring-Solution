param expectedErpFolderCollectorHosts = [
  'ERP-APP-01'
]

param diskWarningFreePercent = 20
param diskCriticalFreePercent = 10

param diskWarningFreeGb = 50
param diskCriticalFreeGb = 20

param diskLatencyThresholdMs = 25

param erpFolderGrowthThresholdGb = 5