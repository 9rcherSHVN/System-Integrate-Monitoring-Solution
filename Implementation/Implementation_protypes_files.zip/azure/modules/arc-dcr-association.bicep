@description('Resource ID of the Azure Arc-enabled server.')
param arcMachineResourceId string

@description('Resource ID of the Data Collection Rule.')
param dataCollectionRuleResourceId string

@description('Association name.')
param associationName string

resource arcMachine 'Microsoft.HybridCompute/machines@2023-10-03-preview' existing = {
  scope: resourceGroup(
    split(arcMachineResourceId, '/')[4],
    split(arcMachineResourceId, '/')[8]
  )
  name: last(split(arcMachineResourceId, '/'))
}

resource association 'Microsoft.Insights/dataCollectionRuleAssociations@2023-03-11' = {
  scope: arcMachine
  name: associationName
  properties: {
    dataCollectionRuleId: dataCollectionRuleResourceId
  }
}

output associationResourceId string = association.id