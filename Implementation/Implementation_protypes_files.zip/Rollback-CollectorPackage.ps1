[CmdletBinding()]
param(
    [string] $CollectorRoot = 'C:\ProgramData\Contoso\AzureMonitorCollectors'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$currentPath = Join-Path $CollectorRoot 'Current'
$previousPath = Join-Path $CollectorRoot 'Previous'
$rollbackPath = Join-Path $CollectorRoot 'Rollback-Staging'

if (-not (Test-Path -LiteralPath $previousPath -PathType Container)) {
    throw 'No previous collector package is available for rollback.'
}

Get-ScheduledTask -TaskName 'Contoso-Monitor-*' -ErrorAction SilentlyContinue |
    Stop-ScheduledTask -ErrorAction SilentlyContinue

Start-Sleep -Seconds 5

Remove-Item -LiteralPath $rollbackPath -Recurse -Force -ErrorAction SilentlyContinue

if (Test-Path -LiteralPath $currentPath) {
    Move-Item -LiteralPath $currentPath -Destination $rollbackPath -Force
}

Move-Item -LiteralPath $previousPath -Destination $currentPath -Force

if (Test-Path -LiteralPath $rollbackPath) {
    Move-Item -LiteralPath $rollbackPath -Destination $previousPath -Force
}

Write-Output 'Collector package rollback completed successfully.'
Write-Output "Active release: $currentPath"
Write-Output "Previous release: $previousPath"