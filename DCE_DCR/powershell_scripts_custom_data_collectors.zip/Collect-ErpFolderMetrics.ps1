[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [hashtable[]] $FolderDefinitions,

    [Parameter(Mandatory)]
    [string] $IngestionEndpoint,

    [Parameter(Mandatory)]
    [string] $DcrImmutableId,

    [string] $StreamName = 'Custom-ErpFolderMetrics',

    [ValidateRange(1, 3650)]
    [int] $RetentionDays = 30
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Import-Module "$PSScriptRoot\AzureMonitorIngestion.psm1" -Force

function Get-FolderMetrics {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string] $Application,

        [Parameter(Mandatory)]
        [string] $Path,

        [Parameter(Mandatory)]
        [int] $RetentionDays
    )

    $scanStarted = (Get-Date).ToUniversalTime()
    $retentionCutoff = $scanStarted.AddDays(-$RetentionDays)

    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        return [pscustomobject]@{
            TimeGenerated          = $scanStarted.ToString('o')
            Computer               = $env:COMPUTERNAME
            Application            = $Application
            FolderPath             = $Path
            TotalBytes             = 0
            TotalGB                = 0
            FileCount              = 0
            OldestFileUtc          = $null
            NewestFileUtc          = $null
            FilesOlderThanRetention = 0
            RetentionDays          = $RetentionDays
            AccessErrorCount       = 0
            ScanDurationSeconds    = 0
            CollectionStatus       = 'FolderNotFound'
            CollectorVersion       = '1.0.0'
        }
    }

    [Int64]$totalBytes = 0
    [Int64]$fileCount = 0
    [Int64]$oldFileCount = 0
    [Int64]$accessErrors = 0
    [DateTime]$oldestFile = [DateTime]::MaxValue
    [DateTime]$newestFile = [DateTime]::MinValue

    $directories = [System.Collections.Generic.Stack[string]]::new()
    $directories.Push((Resolve-Path -LiteralPath $Path).Path)

    while ($directories.Count -gt 0) {
        $currentDirectory = $directories.Pop()

        try {
            foreach ($file in [IO.Directory]::EnumerateFiles(
                $currentDirectory,
                '*',
                [IO.SearchOption]::TopDirectoryOnly
            )) {
                try {
                    $info = [IO.FileInfo]::new($file)

                    $totalBytes += $info.Length
                    $fileCount++

                    $lastWriteUtc = $info.LastWriteTimeUtc

                    if ($lastWriteUtc -lt $oldestFile) {
                        $oldestFile = $lastWriteUtc
                    }

                    if ($lastWriteUtc -gt $newestFile) {
                        $newestFile = $lastWriteUtc
                    }

                    if ($lastWriteUtc -lt $retentionCutoff) {
                        $oldFileCount++
                    }
                }
                catch {
                    $accessErrors++
                }
            }

            foreach ($subDirectory in [IO.Directory]::EnumerateDirectories(
                $currentDirectory,
                '*',
                [IO.SearchOption]::TopDirectoryOnly
            )) {
                try {
                    $directoryInfo = [IO.DirectoryInfo]::new($subDirectory)

                    if (
                        ($directoryInfo.Attributes -band
                            [IO.FileAttributes]::ReparsePoint) -ne 0
                    ) {
                        continue
                    }

                    $directories.Push($directoryInfo.FullName)
                }
                catch {
                    $accessErrors++
                }
            }
        }
        catch {
            $accessErrors++
        }
    }

    $scanCompleted = (Get-Date).ToUniversalTime()

    [pscustomobject]@{
        TimeGenerated           = $scanStarted.ToString('o')
        Computer                = $env:COMPUTERNAME
        Application             = $Application
        FolderPath              = $Path
        TotalBytes              = $totalBytes
        TotalGB                 = [Math]::Round($totalBytes / 1GB, 3)
        FileCount               = $fileCount
        OldestFileUtc           = if ($fileCount -gt 0) {
            $oldestFile.ToString('o')
        } else {
            $null
        }
        NewestFileUtc           = if ($fileCount -gt 0) {
            $newestFile.ToString('o')
        } else {
            $null
        }
        FilesOlderThanRetention = $oldFileCount
        RetentionDays           = $RetentionDays
        AccessErrorCount        = $accessErrors
        ScanDurationSeconds     = [Math]::Round(
            ($scanCompleted - $scanStarted).TotalSeconds,
            2
        )
        CollectionStatus        = if ($accessErrors -gt 0) {
            'PartialSuccess'
        } else {
            'Success'
        }
        CollectorVersion        = '1.0.0'
    }
}

$records = [System.Collections.Generic.List[object]]::new()

foreach ($definition in $FolderDefinitions) {
    if (
        -not $definition.ContainsKey('Application') -or
        -not $definition.ContainsKey('Path')
    ) {
        throw 'Each folder definition requires Application and Path.'
    }

    $records.Add(
        (Get-FolderMetrics `
            -Application $definition.Application `
            -Path $definition.Path `
            -RetentionDays $RetentionDays)
    )
}

Send-AzureMonitorRecords `
    -Endpoint $IngestionEndpoint `
    -DcrImmutableId $DcrImmutableId `
    -StreamName $StreamName `
    -Records $records.ToArray()

Write-Output "Submitted $($records.Count) folder metric records."