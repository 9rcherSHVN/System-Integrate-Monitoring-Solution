param(
    [Parameter(Mandatory)]
    [string] $ResourceGroupName,

    [Parameter(Mandatory)]
    [string[]] $ArcMachineNames
)

foreach ($machineName in $ArcMachineNames) {
    $machine = az connectedmachine show `
        --resource-group $ResourceGroupName `
        --name $machineName `
        --query '{Name:name, PrincipalId:identity.principalId, TenantId:identity.tenantId}' `
        --output json |
        ConvertFrom-Json

    [pscustomobject]@{
        ArcMachineName = $machine.Name
        PrincipalId    = $machine.PrincipalId
        TenantId       = $machine.TenantId
    }
}