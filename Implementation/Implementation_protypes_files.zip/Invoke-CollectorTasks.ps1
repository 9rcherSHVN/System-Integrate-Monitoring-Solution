Start-ScheduledTask -TaskName 'Contoso-Monitor-CertificateInventory'
Start-ScheduledTask -TaskName 'Contoso-Monitor-ErpFolderMetrics'