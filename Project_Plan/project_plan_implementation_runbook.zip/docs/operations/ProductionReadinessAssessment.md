# ERP Hybrid Monitoring Production Readiness Assessment

## Deployment Summary

- Pilot start date:
- Pilot end date:
- Azure region:
- Monitoring resource group:
- Log Analytics Workspace:
- Data Collection Endpoint:
- DCRs:
- Collector release:
- Servers monitored:
- Certificate stores:
- ERP log directories:
- Notification channels:

## Functional Acceptance

| Capability | Result | Evidence | Owner |
|---|---|---|---|
| Certificate inventory | Pass / Fail | | |
| Certificate expiry alert | Pass / Fail | | |
| IIS binding correlation | Pass / Fail | | |
| Disk capacity alert | Pass / Fail | | |
| ERP log-folder growth alert | Pass / Fail | | |
| Collector health | Pass / Fail | | |
| Missing telemetry detection | Pass / Fail | | |
| Email notification | Pass / Fail | | |
| Teams notification | Pass / Fail | | |
| Spool replay | Pass / Fail | | |
| Collector rollback | Pass / Fail | | |

## Security Acceptance

- Arc system-assigned managed identity:
- DCR-scope RBAC:
- Script-signing result:
- Task account review:
- NTFS ACL review:
- Data classification review:
- Secret scanning result:

## Cost and Performance

- Daily ingestion:
- Monthly cost estimate:
- Workspace retention:
- Logic App execution estimate:
- Maximum collector CPU:
- Maximum collector memory:
- Maximum folder scan duration:
- Maximum spool size:

## Open Risks

| Risk | Severity | Owner | Target date | Accepted |
|---|---:|---|---|---|

## Recommendation

- [ ] Approve production rollout.
- [ ] Extend pilot.
- [ ] Remediate gaps before production.
- [ ] Redesign selected components.

## Approvals

| Role | Name | Date | Approval |
|---|---|---|---|
| System Solution Architect | | | |
| System Integration Lead | | | |
| Windows Infrastructure Lead | | | |
| ERP Application Owner | | | |
| Security/IAM Lead | | | |
| Monitoring Operations Lead | | | |
| Budget Owner | | | |