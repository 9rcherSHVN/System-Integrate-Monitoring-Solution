[CmdletBinding()]
param(
    [string] $CollectorRoot = 'C:\ProgramData\Contoso\AzureMonitorCollectors',

    [Parameter(Mandatory)]
    [string] $ErpLogPath,

    [switch] $RequireIisBindingDiscovery
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

$failures = [System.Collections.Generic.List[string]]::new()
$warnings = [System.Collections.Generic.List[string]]::new()

if ($PSVersionTable.PSVersion -lt [Version]'5.1') {
    $failures.Add("PowerShell 5.1 or newer is required. Found: $($PSVersionTable.PSVersion)")
}

$himds = Get-Service -Name 'himds' -ErrorAction SilentlyContinue

if ($null -eq $himds) {
    $failures.Add('Azure Arc HIMDS service is not installed or cannot be found.')
}
elseif ($himds.Status -ne 'Running') {
    $failures.Add("Azure Arc HIMDS service is not running. Current state: $($himds.Status)")
}

if ([string]::IsNullOrWhiteSpace($env:IDENTITY_ENDPOINT)) {
    $warnings.Add(
        'IDENTITY_ENDPOINT is not visible in this shell. Confirm it is visible to the ' +
        'scheduled-task execution context and that Azure Arc managed identity is enabled.'
    )
}

if (-not (Test-Path -LiteralPath 'Cert:\LocalMachine\WebHosting')) {
    $failures.Add('Certificate store Cert:\LocalMachine\WebHosting is unavailable.')
}

try {
    Get-ChildItem -LiteralPath 'Cert:\LocalMachine\WebHosting' -ErrorAction Stop |
        Select-Object -First 1 | Out-Null
}
catch {
    $failures.Add(
        "The current account cannot enumerate Cert:\LocalMachine\WebHosting. $($_.Exception.Message)"
    )
}

if (-not (Test-Path -LiteralPath $ErpLogPath -PathType Container)) {
    $failures.Add("ERP log directory does not exist: $ErpLogPath")
}
else {
    try {
        Get-ChildItem -LiteralPath $ErpLogPath -Force -ErrorAction Stop |
            Select-Object -First 1 | Out-Null
    }
    catch {
        $failures.Add(
            "The current account cannot read ERP log directory '$ErpLogPath'. " +
            "$($_.Exception.Message)"
        )
    }
}

if ($RequireIisBindingDiscovery -and
    -not (Get-Module -ListAvailable -Name WebAdministration)) {
    $warnings.Add(
        'WebAdministration module is unavailable. IIS binding discovery will be skipped.'
    )
}

try {
    New-Item -Path $CollectorRoot -ItemType Directory -Force -ErrorAction Stop | Out-Null
}
catch {
    $failures.Add("Cannot create/access collector root '$CollectorRoot'. $($_.Exception.Message)")
}

Write-Output '--- Collector Prerequisite Validation ---'

foreach ($warning in $warnings) {
    Write-Warning $warning
}

foreach ($failure in $failures) {
    Write-Error $failure
}

if ($failures.Count -gt 0) {
    Write-Output "Validation failed. Failures=$($failures.Count); Warnings=$($warnings.Count)"
    exit 1
}

Write-Output "Validation passed. Warnings=$($warnings.Count)"
exit 0