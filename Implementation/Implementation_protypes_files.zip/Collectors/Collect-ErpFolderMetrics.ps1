[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$collectorRoot = Split-Path -Path $PSScriptRoot -Parent
$modulePath = Join-Path $collectorRoot 'Modules\AzureMonitorCollector.Common.psm1'
$configRoot = Join-Path $collectorRoot 'Config'

Import-Module $modulePath -Force

$sharedSettings = Read-CollectorJsonConfiguration `
    -Path (Join-Path $configRoot 'CollectorSettings.json')

$collectorSettings = Read-CollectorJsonConfiguration `
    -Path (Join-Path $configRoot 'ErpFolderMetrics.config.json')

if (-not [bool]$collectorSettings.Enabled) {
    Write-Output 'ERP folder metrics collector is disabled by configuration.'
    exit 0
}

$collectorName = [string]$collectorSettings.CollectorName
$executionId = [guid]::NewGuid().ToString()
$startedUtc = (Get-Date).ToUniversalTime()
$logDirectory = Join-Path $sharedSettings.CollectorRoot "Logs\$collectorName"
$spoolDirectory = Join-Path $sharedSettings.CollectorRoot "Spool\$collectorName"
$lockPath = Join-Path $sharedSettings.CollectorRoot "Locks\$collectorName.lock"
$lockHandle = $null

$recordsCollected = 0
$recordsSubmitted = 0
$status = 'Success'
$errorCode = $null
$errorMessage = $null

function Get-ErpFolderMetric {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [pscustomobject] $FolderDefinition,

        [Parameter(Mandatory)]
        [pscustomobject] $SharedSettings,

        [Parameter(Mandatory)]
        [pscustomobject] $CollectorSettings,

        [Parameter(Mandatory)]
        [string] $ExecutionId,

        [Parameter(Mandatory)]
        [string] $LogDirectory
    )

    $scanStartedUtc = (Get-Date).ToUniversalTime()
    $path = [string]$FolderDefinition.Path
    $retentionDays = if ($null -ne $FolderDefinition.RetentionDays) {
        [int]$FolderDefinition.RetentionDays
    }
    else {
        [int]$CollectorSettings.DefaultRetentionDays
    }

    if (-not (Test-Path -LiteralPath $path -PathType Container)) {
        return [pscustomobject]@{
            TimeGenerated           = $scanStartedUtc.ToString('o')
            Computer                = $env:COMPUTERNAME
            Environment             = $SharedSettings.Environment
            Application             = $FolderDefinition.Application
            FolderPath              = $path
            TotalBytes              = [Int64]0
            TotalGB                 = [double]0
            FileCount               = [Int64]0
            OldestFileUtc           = $null
            NewestFileUtc           = $null
            FilesOlderThanRetention = [Int64]0
            RetentionDays           = [Int64]$retentionDays
            AccessErrorCount        = [Int64]0
            ScanDurationSeconds     = [double]0
            CollectionStatus        = 'FolderNotFound'
            CollectorVersion        = '1.0.0'
        }
    }

    $cutoffUtc = $scanStartedUtc.AddDays(-$retentionDays)
    $maximumScanDuration = [TimeSpan]::FromMinutes(
        [int]$CollectorSettings.MaximumScanDurationMinutes
    )

    [Int64]$totalBytes = 0
    [Int64]$fileCount = 0
    [Int64]$oldFileCount = 0
    [Int64]$accessErrors = 0
    [DateTime]$oldestFileUtc = [DateTime]::MaxValue
    [DateTime]$newestFileUtc = [DateTime]::MinValue
    $timedOut = $false

    $directoryStack = [System.Collections.Generic.Stack[string]]::new()
    $directoryStack.Push((Resolve-Path -LiteralPath $path).Path)

    while ($directoryStack.Count -gt 0) {
        if (((Get-Date).ToUniversalTime() - $scanStartedUtc) -gt $maximumScanDuration) {
            $timedOut = $true
            break
        }

        $currentDirectory = $directoryStack.Pop()

        try {
            foreach ($filePath in [System.IO.Directory]::EnumerateFiles(
                $currentDirectory,
                '*',
                [System.IO.SearchOption]::TopDirectoryOnly
            )) {
                try {
                    $file = [System.IO.FileInfo]::new($filePath)

                    $totalBytes += $file.Length
                    $fileCount++

                    if ($file.LastWriteTimeUtc -lt $oldestFileUtc) {
                        $oldestFileUtc = $file.LastWriteTimeUtc
                    }

                    if ($file.LastWriteTimeUtc -gt $newestFileUtc) {
                        $newestFileUtc = $file.LastWriteTimeUtc
                    }

                    if ($file.LastWriteTimeUtc -lt $cutoffUtc) {
                        $oldFileCount++
                    }
                }
                catch {
                    $accessErrors++
                }
            }

            foreach ($subDirectoryPath in [System.IO.Directory]::EnumerateDirectories(
                $currentDirectory,
                '*',
                [System.IO.SearchOption]::TopDirectoryOnly
            )) {
                try {
                    $subDirectory = [System.IO.DirectoryInfo]::new($subDirectoryPath)

                    # Avoid traversing junctions, symbolic links, mount points, and other
                    # reparse points that can create loops or scan unrelated storage.
                    if (
                        ($subDirectory.Attributes -band
                            [System.IO.FileAttributes]::ReparsePoint) -ne 0
                    ) {
                        continue
                    }

                    $directoryStack.Push($subDirectory.FullName)
                }
                catch {
                    $accessErrors++
                }
            }
        }
        catch {
            $accessErrors++
        }
    }

    $scanCompletedUtc = (Get-Date).ToUniversalTime()

    $collectionStatus = if ($timedOut) {
        'ScanTimedOut'
    }
    elseif ($accessErrors -gt 0) {
        'PartialSuccess'
    }
    else {
        'Success'
    }

    if ($timedOut) {
        Write-CollectorLog `
            -LogDirectory $LogDirectory `
            -Level Warning `
            -ExecutionId $ExecutionId `
            -Message (
                "Folder scan timed out after $($CollectorSettings.MaximumScanDurationMinutes) " +
                "minutes: $path"
            )
    }

    return [pscustomobject]@{
        TimeGenerated           = $scanStartedUtc.ToString('o')
        Computer                = $env:COMPUTERNAME
        Environment             = $SharedSettings.Environment
        Application             = $FolderDefinition.Application
        FolderPath              = $path
        TotalBytes              = $totalBytes
        TotalGB                 = [Math]::Round($totalBytes / 1GB, 3)
        FileCount               = $fileCount
        OldestFileUtc           = if ($fileCount -gt 0) {
            $oldestFileUtc.ToString('o')
        } else {
            $null
        }
        NewestFileUtc           = if ($fileCount -gt 0) {
            $newestFileUtc.ToString('o')
        } else {
            $null
        }
        FilesOlderThanRetention = $oldFileCount
        RetentionDays           = [Int64]$retentionDays
        AccessErrorCount        = $accessErrors
        ScanDurationSeconds     = [Math]::Round(
            ($scanCompletedUtc - $scanStartedUtc).TotalSeconds,
            3
        )
        CollectionStatus        = $collectionStatus
        CollectorVersion        = '1.0.0'
    }
}

try {
    $lockHandle = Enter-CollectorLock -LockPath $lockPath

    Write-CollectorLog `
        -LogDirectory $logDirectory `
        -Level Information `
        -ExecutionId $executionId `
        -Message 'ERP folder metrics collection started.'

    Remove-CollectorExpiredFiles `
        -Directory $logDirectory `
        -RetentionDays ([int]$sharedSettings.Logging.RetentionDays)

    Remove-CollectorExpiredFiles `
        -Directory $spoolDirectory `
        -RetentionDays ([int]$sharedSettings.Ingestion.SpoolRetentionDays)

    Submit-CollectorSpoolBatches `
        -SpoolDirectory $spoolDirectory `
        -SharedSettings $sharedSettings `
        -LogDirectory $logDirectory `
        -ExecutionId $executionId | Out-Null

    $records = [System.Collections.Generic.List[object]]::new()

    foreach ($folderDefinition in $collectorSettings.Folders) {
        if (-not [bool]$folderDefinition.Enabled) {
            continue
        }

        $folderRecord = Get-ErpFolderMetric `
            -FolderDefinition $folderDefinition `
            -SharedSettings $sharedSettings `
            -CollectorSettings $collectorSettings `
            -ExecutionId $executionId `
            -LogDirectory $logDirectory

        if ($folderRecord.CollectionStatus -ne 'Success') {
            $status = 'PartialSuccess'
        }

        $records.Add($folderRecord)
    }

    $recordsCollected = $records.Count

    $recordsSubmitted = Send-AzureMonitorRecords `
        -CollectorName $collectorName `
        -IngestionEndpoint $collectorSettings.IngestionEndpoint `
        -DcrImmutableId $collectorSettings.DcrImmutableId `
        -StreamName $collectorSettings.StreamName `
        -Records $records.ToArray() `
        -SharedSettings $sharedSettings `
        -SpoolDirectory $spoolDirectory `
        -LogDirectory $logDirectory `
        -ExecutionId $executionId

    Write-CollectorLog `
        -LogDirectory $logDirectory `
        -Level Information `
        -ExecutionId $executionId `
        -Message (
            "ERP folder metrics completed. Collected=$recordsCollected; " +
            "submitted=$recordsSubmitted."
        )
}
catch {
    $status = 'Failed'
    $errorCode = 'ErpFolderMetricsFailure'
    $errorMessage = $_.Exception.Message

    Write-CollectorLog `
        -LogDirectory $logDirectory `
        -Level Error `
        -ExecutionId $executionId `
        -Message "ERP folder metrics collector failed. Error: $errorMessage"
}
finally {
    $healthRecord = New-CollectorHealthRecord `
        -CollectorName $collectorName `
        -ExecutionId $executionId `
        -StartedUtc $startedUtc `
        -Status $status `
        -RecordsCollected $recordsCollected `
        -RecordsSubmitted $recordsSubmitted `
        -TargetScope (
            ($collectorSettings.Folders |
                Where-Object { $_.Enabled } |
                ForEach-Object { $_.Path }) -join ';'
        ) `
        -ErrorCode $errorCode `
        -ErrorMessage $errorMessage `
        -CollectorVersion '1.0.0'

    try {
        Send-AzureMonitorRecords `
            -CollectorName $collectorName `
            -IngestionEndpoint $collectorSettings.HealthIngestionEndpoint `
            -DcrImmutableId $collectorSettings.HealthDcrImmutableId `
            -StreamName $collectorSettings.HealthStreamName `
            -Records @($healthRecord) `
            -SharedSettings $sharedSettings `
            -SpoolDirectory $spoolDirectory `
            -LogDirectory $logDirectory `
            -ExecutionId $executionId | Out-Null
    }
    catch {
        Write-CollectorLog `
            -LogDirectory $logDirectory `
            -Level Error `
            -ExecutionId $executionId `
            -Message (
                "Unable to submit collector-health record. Error: $($_.Exception.Message)"
            )
    }

    if ($lockHandle) {
        Exit-CollectorLock -LockHandle $lockHandle -LockPath $lockPath
    }
}

if ($status -eq 'Failed') {
    exit 1
}

exit 0