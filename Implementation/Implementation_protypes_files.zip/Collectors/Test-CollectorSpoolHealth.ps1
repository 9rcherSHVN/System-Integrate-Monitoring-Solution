[CmdletBinding()]
param(
    [string] $CollectorRoot = 'C:\ProgramData\Contoso\AzureMonitorCollectors',

    [int] $WarningFileCount = 10,

    [int] $CriticalFileCount = 100,

    [int] $MaximumOldestFileAgeMinutes = 60
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$spoolRoot = Join-Path $CollectorRoot 'Spool'

if (-not (Test-Path -LiteralPath $spoolRoot)) {
    Write-Output 'Spool directory does not exist; no queued batches found.'
    exit 0
}

$files = Get-ChildItem -LiteralPath $spoolRoot -Recurse -File -Filter '*.json'

$count = $files.Count
$oldestFile = $files | Sort-Object LastWriteTimeUtc | Select-Object -First 1

$oldestAgeMinutes = if ($oldestFile) {
    [Math]::Round(
        ((Get-Date).ToUniversalTime() - $oldestFile.LastWriteTimeUtc).TotalMinutes,
        2
    )
}
else {
    0
}

$result = [pscustomobject]@{
    TimeGenerated        = (Get-Date).ToUniversalTime().ToString('o')
    Computer             = $env:COMPUTERNAME
    SpoolFileCount       = $count
    OldestFileAgeMinutes = $oldestAgeMinutes
    Status               = if ($count -ge $CriticalFileCount -or
                               $oldestAgeMinutes -ge $MaximumOldestFileAgeMinutes) {
        'Critical'
    }
    elseif ($count -ge $WarningFileCount) {
        'Warning'
    }
    else {
        'Success'
    }
}

$result | ConvertTo-Json -Compress