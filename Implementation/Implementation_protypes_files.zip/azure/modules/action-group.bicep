@description('Azure region for the Action Group resource.')
param location string

@description('Action Group name.')
param actionGroupName string

@description('Deployment environment.')
param environment string

@description('Email address or distribution list for operations alerts.')
param operationsEmailAddress string

resource actionGroup 'Microsoft.Insights/actionGroups@2023-01-01' = {
  name: actionGroupName
  location: 'global'
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    SupportTeam: 'ERP-Platform-Support'
  }
  properties: {
    groupShortName: 'ERPMonOps'
    enabled: true
    emailReceivers: [
      {
        name: 'OperationsEmail'
        emailAddress: operationsEmailAddress
        useCommonAlertSchema: true
      }
    ]
  }
}

output actionGroupResourceId string = actionGroup.id