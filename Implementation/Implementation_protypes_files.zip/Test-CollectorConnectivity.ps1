$targets = @(
    'https://login.microsoftonline.com/',
    'https://management.azure.com/',
    '<Azure-Monitor-ingestion-endpoint-from-DCR-or-DCE>'
)

foreach ($target in $targets) {
    try {
        $result = Invoke-WebRequest `
            -Uri $target `
            -Method Head `
            -UseBasicParsing `
            -TimeoutSec 30 `
            -ErrorAction Stop

        Write-Output "SUCCESS: $target - HTTP $($result.StatusCode)"
    }
    catch {
        Write-Warning "FAILED: $target - $($_.Exception.Message)"
    }
}