@description('Log Analytics Workspace name.')
param workspaceName string

@description('Deployment environment.')
param environment string

resource workspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: workspaceName
}

resource certificateTable 'Microsoft.OperationalInsights/workspaces/tables@2022-10-01' = {
  parent: workspace
  name: 'ServerCertificateInventory_CL'
  properties: {
    plan: 'Analytics'
    retentionInDays: 90
    totalRetentionInDays: 90
    schema: {
      name: 'ServerCertificateInventory_CL'
      columns: [
        {
          name: 'TimeGenerated'
          type: 'datetime'
        }
        {
          name: 'Computer'
          type: 'string'
        }
        {
          name: 'Environment'
          type: 'string'
        }
        {
          name: 'Application'
          type: 'string'
        }
        {
          name: 'StoreLocation'
          type: 'string'
        }
        {
          name: 'StoreName'
          type: 'string'
        }
        {
          name: 'Subject'
          type: 'string'
        }
        {
          name: 'DnsNames'
          type: 'string'
        }
        {
          name: 'Issuer'
          type: 'string'
        }
        {
          name: 'Thumbprint'
          type: 'string'
        }
        {
          name: 'SerialNumber'
          type: 'string'
        }
        {
          name: 'NotBefore'
          type: 'datetime'
        }
        {
          name: 'NotAfter'
          type: 'datetime'
        }
        {
          name: 'DaysUntilExpiry'
          type: 'long'
        }
        {
          name: 'HasPrivateKey'
          type: 'boolean'
        }
        {
          name: 'EnhancedKeyUsage'
          type: 'string'
        }
        {
          name: 'IisBindings'
          type: 'string'
        }
        {
          name: 'CollectionStatus'
          type: 'string'
        }
        {
          name: 'CollectorVersion'
          type: 'string'
        }
      ]
    }
  }
}

resource folderMetricsTable 'Microsoft.OperationalInsights/workspaces/tables@2022-10-01' = {
  parent: workspace
  name: 'ErpFolderMetrics_CL'
  properties: {
    plan: 'Analytics'
    retentionInDays: 90
    totalRetentionInDays: 90
    schema: {
      name: 'ErpFolderMetrics_CL'
      columns: [
        {
          name: 'TimeGenerated'
          type: 'datetime'
        }
        {
          name: 'Computer'
          type: 'string'
        }
        {
          name: 'Environment'
          type: 'string'
        }
        {
          name: 'Application'
          type: 'string'
        }
        {
          name: 'FolderPath'
          type: 'string'
        }
        {
          name: 'TotalBytes'
          type: 'long'
        }
        {
          name: 'TotalGB'
          type: 'real'
        }
        {
          name: 'FileCount'
          type: 'long'
        }
        {
          name: 'OldestFileUtc'
          type: 'datetime'
        }
        {
          name: 'NewestFileUtc'
          type: 'datetime'
        }
        {
          name: 'FilesOlderThanRetention'
          type: 'long'
        }
        {
          name: 'RetentionDays'
          type: 'long'
        }
        {
          name: 'AccessErrorCount'
          type: 'long'
        }
        {
          name: 'ScanDurationSeconds'
          type: 'real'
        }
        {
          name: 'CollectionStatus'
          type: 'string'
        }
        {
          name: 'CollectorVersion'
          type: 'string'
        }
      ]
    }
  }
}

resource collectorHealthTable 'Microsoft.OperationalInsights/workspaces/tables@2022-10-01' = {
  parent: workspace
  name: 'CollectorHealth_CL'
  properties: {
    plan: 'Analytics'
    retentionInDays: 90
    totalRetentionInDays: 90
    schema: {
      name: 'CollectorHealth_CL'
      columns: [
        {
          name: 'TimeGenerated'
          type: 'datetime'
        }
        {
          name: 'CollectorName'
          type: 'string'
        }
        {
          name: 'Computer'
          type: 'string'
        }
        {
          name: 'TargetScope'
          type: 'string'
        }
        {
          name: 'ExecutionId'
          type: 'string'
        }
        {
          name: 'RecordsCollected'
          type: 'long'
        }
        {
          name: 'RecordsSubmitted'
          type: 'long'
        }
        {
          name: 'DurationSeconds'
          type: 'real'
        }
        {
          name: 'Status'
          type: 'string'
        }
        {
          name: 'ErrorCode'
          type: 'string'
        }
        {
          name: 'ErrorMessage'
          type: 'string'
        }
        {
          name: 'CollectorVersion'
          type: 'string'
        }
      ]
    }
  }
}

output certificateTableName string = certificateTable.name
output folderMetricsTableName string = folderMetricsTable.name
output collectorHealthTableName string = collectorHealthTable.name