Register-ScheduledTask `
    -TaskName 'Contoso-Monitor-WindowsDiskMetrics-SpoolReplay' `
    -Action $diskSpoolAction `
    -Trigger $spoolTrigger `
    -Settings $settings `
    -User $CollectorRunAsAccount `
    -Password (
        [Runtime.InteropServices.Marshal]::PtrToStringBSTR(
            [Runtime.InteropServices.Marshal]::SecureStringToBSTR(
                $CollectorRunAsPassword
            )
        )
    ) `
    -RunLevel Limited `
    -Description 'Replays spooled Windows logical-disk telemetry to Azure Monitor.' `
    -Force | Out-Null