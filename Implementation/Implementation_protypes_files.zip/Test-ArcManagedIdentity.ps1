$resource = [uri]::EscapeDataString('https://monitor.azure.com/')
$apiVersion = '2020-06-01'

if ([string]::IsNullOrWhiteSpace($env:IDENTITY_ENDPOINT)) {
    throw 'IDENTITY_ENDPOINT is not available. Confirm Azure Arc managed identity is enabled.'
}

$tokenUri = "$($env:IDENTITY_ENDPOINT)?resource=$resource&api-version=$apiVersion"

$response = Invoke-RestMethod `
    -Method Get `
    -Uri $tokenUri `
    -Headers @{ Metadata = 'True' } `
    -ErrorAction Stop

if ([string]::IsNullOrWhiteSpace($response.access_token)) {
    throw 'No managed identity access token was returned.'
}

Write-Output 'Azure Arc managed identity token acquisition succeeded.'