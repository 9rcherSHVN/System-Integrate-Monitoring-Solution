param(
    [Parameter(Mandatory)]
    [string] $Identity
)

Import-Module ActiveDirectory
Test-ADServiceAccount -Identity $Identity