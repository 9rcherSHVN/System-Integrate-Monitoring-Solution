param(
    [Parameter(Mandatory)]
    [string] $ResourceGroupName,

    [Parameter(Mandatory)]
    [string] $TemplateFile,

    [Parameter(Mandatory)]
    [string] $ParameterFile
)

az deployment group create `
    --name "erpmon-phase2-$(Get-Date -Format 'yyyyMMddHHmmss')" `
    --resource-group $ResourceGroupName `
    --template-file $TemplateFile `
    --parameters $ParameterFile `
    --output json