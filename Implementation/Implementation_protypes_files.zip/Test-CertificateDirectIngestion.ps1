[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string] $IngestionEndpoint,

    [Parameter(Mandatory)]
    [string] $DcrImmutableId,

    [string] $StreamName = 'Custom-ServerCertificateInventoryRaw'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-ArcAccessToken {
    param(
        [string] $Resource = 'https://monitor.azure.com/',
        [string] $ApiVersion = '2020-06-01'
    )

    if ([string]::IsNullOrWhiteSpace($env:IDENTITY_ENDPOINT)) {
        throw 'IDENTITY_ENDPOINT is missing. Azure Arc managed identity is not available.'
    }

    $resourceEncoded = [uri]::EscapeDataString($Resource)

    $tokenUri = '{0}?resource={1}&api-version={2}' -f `
        $env:IDENTITY_ENDPOINT,
        $resourceEncoded,
        $ApiVersion

    $secretFilePath = $null

    try {
        Invoke-WebRequest `
            -Method Get `
            -Uri $tokenUri `
            -Headers @{ Metadata = 'True' } `
            -UseBasicParsing `
            -ErrorAction Stop | Out-Null
    }
    catch {
        $challenge = $_.Exception.Response.Headers['WWW-Authenticate']

        if ($challenge -notmatch 'Basic\s+realm=(.+)$') {
            throw 'The expected Azure Arc HIMDS authentication challenge was not received.'
        }

        $secretFilePath = $Matches[1].Trim('"')
    }

    if (-not (Test-Path -LiteralPath $secretFilePath -PathType Leaf)) {
        throw "HIMDS secret challenge file was not found: $secretFilePath"
    }

    $secret = Get-Content -LiteralPath $secretFilePath -Raw -Encoding UTF8

    $response = Invoke-RestMethod `
        -Method Get `
        -Uri $tokenUri `
        -Headers @{
            Metadata      = 'True'
            Authorization = "Basic $secret"
        } `
        -ErrorAction Stop

    return $response.access_token
}

$record = @{
    TimeGenerated    = (Get-Date).ToUniversalTime().ToString('o')
    Computer         = $env:COMPUTERNAME
    Environment      = 'Pilot'
    Application      = 'ERP'
    StoreLocation    = 'LocalMachine'
    StoreName        = 'WebHosting'
    Subject          = 'CN=AzureMonitorIngestionValidation'
    DnsNames         = 'validation.invalid'
    Issuer           = 'CN=AzureMonitorIngestionValidation'
    Thumbprint       = ('VALIDATION-' + [guid]::NewGuid().ToString('N'))
    SerialNumber     = 'VALIDATION'
    NotBefore        = (Get-Date).ToUniversalTime().ToString('o')
    NotAfter         = (Get-Date).ToUniversalTime().AddDays(30).ToString('o')
    DaysUntilExpiry  = 30
    HasPrivateKey    = $false
    EnhancedKeyUsage = 'ValidationOnly'
    IisBindings      = $null
    CollectionStatus = 'Validation'
    CollectorVersion = '1.0.0'
}

$uri = '{0}/dataCollectionRules/{1}/streams/{2}?api-version=2023-01-01' -f `
    $IngestionEndpoint.TrimEnd('/'),
    [uri]::EscapeDataString($DcrImmutableId),
    [uri]::EscapeDataString($StreamName)

$token = Get-ArcAccessToken
$payload = @($record) | ConvertTo-Json -Depth 8 -Compress

Invoke-RestMethod `
    -Method Post `
    -Uri $uri `
    -Headers @{ Authorization = "Bearer $token" } `
    -ContentType 'application/json; charset=utf-8' `
    -Body ([Text.Encoding]::UTF8.GetBytes($payload)) `
    -ErrorAction Stop | Out-Null

Write-Output 'Direct ingestion request was accepted successfully.'
Write-Output "Validation thumbprint: $($record.Thumbprint)"