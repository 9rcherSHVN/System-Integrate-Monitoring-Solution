param enableCertificateAlerts = true
param certificateAlertNamePrefix = 'sqra-erpmon-cert'