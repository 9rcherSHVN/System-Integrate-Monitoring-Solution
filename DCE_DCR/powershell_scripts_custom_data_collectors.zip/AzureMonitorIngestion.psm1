Set-StrictMode -Version Latest

function ConvertFrom-SecureStringToPlainText {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [SecureString] $SecureString
    )

    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureString)

    try {
        [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    }
    finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }
}

function Get-AzureMonitorBearerToken {
    [CmdletBinding()]
    param()

    $tokenResult = Get-AzAccessToken -ResourceUrl 'https://monitor.azure.com/'

    if ($tokenResult.Token -is [SecureString]) {
        return ConvertFrom-SecureStringToPlainText -SecureString $tokenResult.Token
    }

    return [string]$tokenResult.Token
}

function Send-AzureMonitorRecords {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidatePattern('^https://')]
        [string] $Endpoint,

        [Parameter(Mandatory)]
        [string] $DcrImmutableId,

        [Parameter(Mandatory)]
        [ValidatePattern('^Custom-')]
        [string] $StreamName,

        [Parameter(Mandatory)]
        [object[]] $Records,

        [ValidateRange(1, 10)]
        [int] $MaximumAttempts = 4,

        [ValidateRange(1, 1000)]
        [int] $MaximumRecordsPerBatch = 500,

        [ValidateRange(100000, 950000)]
        [int] $MaximumPayloadBytes = 900000
    )

    if ($Records.Count -eq 0) {
        return
    }

    $normalizedEndpoint = $Endpoint.TrimEnd('/')
    $escapedDcr = [Uri]::EscapeDataString($DcrImmutableId)
    $escapedStream = [Uri]::EscapeDataString($StreamName)

    $uri = (
        '{0}/dataCollectionRules/{1}/streams/{2}?api-version=2023-01-01' -f
        $normalizedEndpoint,
        $escapedDcr,
        $escapedStream
    )

    $token = Get-AzureMonitorBearerToken
    $headers = @{
        Authorization = "Bearer $token"
    }

    $batches = [System.Collections.Generic.List[object]]::new()
    $currentBatch = [System.Collections.Generic.List[object]]::new()
    $currentBytes = 2

    foreach ($record in $Records) {
        $recordJson = $record | ConvertTo-Json -Depth 12 -Compress
        $recordBytes = [Text.Encoding]::UTF8.GetByteCount($recordJson) + 1

        if ($recordBytes -gt $MaximumPayloadBytes) {
            throw "A single telemetry record exceeds the configured payload limit."
        }

        $batchWouldOverflow =
            $currentBatch.Count -ge $MaximumRecordsPerBatch -or
            ($currentBytes + $recordBytes) -gt $MaximumPayloadBytes

        if ($batchWouldOverflow -and $currentBatch.Count -gt 0) {
            $batches.Add($currentBatch.ToArray())
            $currentBatch = [System.Collections.Generic.List[object]]::new()
            $currentBytes = 2
        }

        $currentBatch.Add($record)
        $currentBytes += $recordBytes
    }

    if ($currentBatch.Count -gt 0) {
        $batches.Add($currentBatch.ToArray())
    }

    foreach ($batch in $batches) {
        $body = ConvertTo-Json -InputObject @($batch) -Depth 12 -Compress
        $attempt = 0

        while ($true) {
            $attempt++

            try {
                Invoke-RestMethod `
                    -Method Post `
                    -Uri $uri `
                    -Headers $headers `
                    -ContentType 'application/json; charset=utf-8' `
                    -Body ([Text.Encoding]::UTF8.GetBytes($body)) `
                    -ErrorAction Stop | Out-Null

                break
            }
            catch {
                $statusCode = $null

                if ($_.Exception.Response) {
                    try {
                        $statusCode = [int]$_.Exception.Response.StatusCode
                    }
                    catch {
                        $statusCode = $null
                    }
                }

                $retryable = $statusCode -in @(408, 429, 500, 502, 503, 504)

                if (-not $retryable -or $attempt -ge $MaximumAttempts) {
                    throw
                }

                $delaySeconds = [Math]::Min(60, [Math]::Pow(2, $attempt))
                Start-Sleep -Seconds $delaySeconds
            }
        }
    }
}

Export-ModuleMember -Function Send-AzureMonitorRecords