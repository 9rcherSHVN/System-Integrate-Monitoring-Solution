var diskLatencyQuery = '''
WindowsDiskMetrics_CL
| where TimeGenerated > ago(45m)
| summarize arg_max(TimeGenerated, *) by Computer, Drive
| where CollectionStatus == "Success"
| where ReadLatencyMs > ${diskLatencyThresholdMs} or WriteLatencyMs > ${diskLatencyThresholdMs}
| project Computer, Drive, ReadLatencyMs, WriteLatencyMs, DiskQueueLength, DiskTransfersPerSecond
'''