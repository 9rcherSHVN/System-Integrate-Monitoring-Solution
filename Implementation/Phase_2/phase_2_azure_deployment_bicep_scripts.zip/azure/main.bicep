targetScope = 'resourceGroup'

@description('Azure region for all pilot monitoring resources.')
param location string = resourceGroup().location

@description('Log Analytics Workspace name.')
param logAnalyticsWorkspaceName string

@description('Data Collection Endpoint name.')
param dataCollectionEndpointName string

@description('Certificate inventory DCR name.')
param certificateDcrName string

@description('ERP folder metrics DCR name.')
param folderMetricsDcrName string

@description('Collector health DCR name.')
param collectorHealthDcrName string

@description('Action Group name.')
param actionGroupName string

@description('Short environment label, such as pilot, test, or prod.')
param environment string

@description('Email address for initial Azure Monitor alert notification.')
param operationsEmailAddress string

@description('Azure Arc managed identity principal IDs allowed to submit certificate inventory data.')
param certificateCollectorPrincipalIds array = []

@description('Azure Arc managed identity principal IDs allowed to submit ERP folder metric data.')
param folderCollectorPrincipalIds array = []

@description('Azure Arc managed identity principal IDs allowed to submit collector health data.')
param healthCollectorPrincipalIds array = []

module workspace './modules/log-analytics-workspace.bicep' = {
  name: 'deploy-log-analytics-workspace'
  params: {
    location: location
    workspaceName: logAnalyticsWorkspaceName
    environment: environment
  }
}

module tables './modules/custom-tables.bicep' = {
  name: 'deploy-custom-log-analytics-tables'
  params: {
    workspaceName: logAnalyticsWorkspaceName
    environment: environment
  }
  dependsOn: [
    workspace
  ]
}

module dce './modules/data-collection-endpoint.bicep' = {
  name: 'deploy-data-collection-endpoint'
  params: {
    location: location
    dceName: dataCollectionEndpointName
    environment: environment
  }
}

module dcrs './modules/data-collection-rules.bicep' = {
  name: 'deploy-direct-ingestion-dcrs'
  params: {
    location: location
    workspaceResourceId: workspace.outputs.workspaceResourceId
    dataCollectionEndpointResourceId: dce.outputs.dataCollectionEndpointResourceId
    certificateDcrName: certificateDcrName
    folderMetricsDcrName: folderMetricsDcrName
    collectorHealthDcrName: collectorHealthDcrName
    environment: environment
  }
  dependsOn: [
    workspace
    tables
    dce
  ]
}

module roles './modules/dcr-role-assignments.bicep' = {
  name: 'assign-dcr-ingestion-roles'
  params: {
    certificateDcrResourceId: dcrs.outputs.certificateDcrResourceId
    folderMetricsDcrResourceId: dcrs.outputs.folderMetricsDcrResourceId
    collectorHealthDcrResourceId: dcrs.outputs.collectorHealthDcrResourceId
    certificateCollectorPrincipalIds: certificateCollectorPrincipalIds
    folderCollectorPrincipalIds: folderCollectorPrincipalIds
    healthCollectorPrincipalIds: healthCollectorPrincipalIds
  }
  dependsOn: [
    dcrs
  ]
}

module actionGroup './modules/action-group.bicep' = {
  name: 'deploy-operations-action-group'
  params: {
    location: location
    actionGroupName: actionGroupName
    environment: environment
    operationsEmailAddress: operationsEmailAddress
  }
}

output logAnalyticsWorkspaceResourceId string = workspace.outputs.workspaceResourceId
output logAnalyticsWorkspaceCustomerId string = workspace.outputs.workspaceCustomerId

output dataCollectionEndpointResourceId string = dce.outputs.dataCollectionEndpointResourceId
output logsIngestionEndpoint string = dce.outputs.logsIngestionEndpoint

output certificateDcrResourceId string = dcrs.outputs.certificateDcrResourceId
output certificateDcrImmutableId string = dcrs.outputs.certificateDcrImmutableId

output folderMetricsDcrResourceId string = dcrs.outputs.folderMetricsDcrResourceId
output folderMetricsDcrImmutableId string = dcrs.outputs.folderMetricsDcrImmutableId

output collectorHealthDcrResourceId string = dcrs.outputs.collectorHealthDcrResourceId
output collectorHealthDcrImmutableId string = dcrs.outputs.collectorHealthDcrImmutableId

output actionGroupResourceId string = actionGroup.outputs.actionGroupResourceId