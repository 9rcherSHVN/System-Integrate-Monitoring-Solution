Set-StrictMode -Version Latest

function Get-UtcIso8601 {
    return (Get-Date).ToUniversalTime().ToString('o')
}

function Read-CollectorJsonConfiguration {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string] $Path
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Configuration file does not exist: $Path"
    }

    try {
        return Get-Content -LiteralPath $Path -Raw -Encoding UTF8 |
            ConvertFrom-Json -ErrorAction Stop
    }
    catch {
        throw "Invalid JSON configuration at '$Path'. $($_.Exception.Message)"
    }
}

function Write-CollectorLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string] $LogDirectory,

        [Parameter(Mandatory)]
        [ValidateSet('Debug', 'Information', 'Warning', 'Error')]
        [string] $Level,

        [Parameter(Mandatory)]
        [string] $Message,

        [string] $ExecutionId
    )

    if (-not (Test-Path -LiteralPath $LogDirectory)) {
        New-Item -Path $LogDirectory -ItemType Directory -Force | Out-Null
    }

    $record = [ordered]@{
        TimeGenerated = Get-UtcIso8601
        Level         = $Level
        ExecutionId   = $ExecutionId
        Computer      = $env:COMPUTERNAME
        Message       = $Message
    }

    $fileName = '{0:yyyy-MM-dd}.log' -f (Get-Date)
    $path = Join-Path $LogDirectory $fileName

    # Do not write secrets, access tokens, private keys, full ingestion payloads,
    # passwords, or raw HTTP headers to the local log.
    ($record | ConvertTo-Json -Compress) |
        Add-Content -LiteralPath $path -Encoding UTF8
}

function Remove-CollectorExpiredFiles {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string] $Directory,

        [Parameter(Mandatory)]
        [ValidateRange(1, 3650)]
        [int] $RetentionDays
    )

    if (-not (Test-Path -LiteralPath $Directory)) {
        return
    }

    $cutoff = (Get-Date).ToUniversalTime().AddDays(-$RetentionDays)

    Get-ChildItem -LiteralPath $Directory -File -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTimeUtc -lt $cutoff } |
        Remove-Item -Force -ErrorAction SilentlyContinue
}

function Enter-CollectorLock {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string] $LockPath
    )

    $lockDirectory = Split-Path -Path $LockPath -Parent

    if (-not (Test-Path -LiteralPath $lockDirectory)) {
        New-Item -Path $lockDirectory -ItemType Directory -Force | Out-Null
    }

    try {
        return [System.IO.File]::Open(
            $LockPath,
            [System.IO.FileMode]::OpenOrCreate,
            [System.IO.FileAccess]::ReadWrite,
            [System.IO.FileShare]::None
        )
    }
    catch {
        throw "Another instance is already running. Lock: $LockPath"
    }
}

function Exit-CollectorLock {
    [CmdletBinding()]
    param(
        [Parameter()]
        [System.IO.FileStream] $LockHandle,

        [Parameter(Mandatory)]
        [string] $LockPath
    )

    if ($null -ne $LockHandle) {
        $LockHandle.Dispose()
    }

    Remove-Item -LiteralPath $LockPath -Force -ErrorAction SilentlyContinue
}

function Get-ArcManagedIdentityAccessToken {
    [CmdletBinding()]
    param(
        [string] $Resource = 'https://monitor.azure.com/',

        [string] $ApiVersion = '2020-06-01'
    )

    if ([string]::IsNullOrWhiteSpace($env:IDENTITY_ENDPOINT)) {
        throw (
            'IDENTITY_ENDPOINT is not available. Confirm Azure Arc onboarding and ' +
            'that the system-assigned managed identity is enabled.'
        )
    }

    $endpoint = [uri]$env:IDENTITY_ENDPOINT

    if (-not $endpoint.IsLoopback) {
        throw "IDENTITY_ENDPOINT is not a loopback address: $($endpoint.AbsoluteUri)"
    }

    $resourceEncoded = [uri]::EscapeDataString($Resource)
    $uri = '{0}?resource={1}&api-version={2}' -f `
        $endpoint.AbsoluteUri,
        $resourceEncoded,
        $ApiVersion

    $metadataHeaders = @{
        Metadata = 'True'
    }

    $secretFilePath = $null

    try {
        # Azure Arc HIMDS normally responds with a 401 challenge that provides a
        # local secret file through its WWW-Authenticate header.
        Invoke-WebRequest `
            -Method Get `
            -Uri $uri `
            -Headers $metadataHeaders `
            -UseBasicParsing `
            -TimeoutSec 30 `
            -ErrorAction Stop | Out-Null

        throw (
            'Unexpected HIMDS response: a local challenge was expected but was not returned.'
        )
    }
    catch {
        if ($null -eq $_.Exception.Response) {
            throw "Unable to contact Azure Arc HIMDS. $($_.Exception.Message)"
        }

        $wwwAuthenticate = $_.Exception.Response.Headers['WWW-Authenticate']

        if ([string]::IsNullOrWhiteSpace($wwwAuthenticate)) {
            throw (
                'Azure Arc HIMDS did not return a WWW-Authenticate challenge. ' +
                "HTTP response: $($_.Exception.Response.StatusCode)"
            )
        }

        if ($wwwAuthenticate -notmatch 'Basic\s+realm=(.+)$') {
            throw "Unexpected Azure Arc HIMDS authentication challenge."
        }

        $secretFilePath = $Matches[1].Trim('"')
    }

    if (-not (Test-Path -LiteralPath $secretFilePath -PathType Leaf)) {
        throw "Azure Arc HIMDS secret file is unavailable: $secretFilePath"
    }

    $secret = Get-Content -LiteralPath $secretFilePath -Raw -Encoding UTF8

    try {
        $tokenResponse = Invoke-RestMethod `
            -Method Get `
            -Uri $uri `
            -Headers @{
                Metadata      = 'True'
                Authorization = "Basic $secret"
            } `
            -TimeoutSec 30 `
            -ErrorAction Stop
    }
    catch {
        throw "Azure Arc managed identity token request failed. $($_.Exception.Message)"
    }

    if ([string]::IsNullOrWhiteSpace($tokenResponse.access_token)) {
        throw 'Azure Arc HIMDS did not return an access token.'
    }

    return [string]$tokenResponse.access_token
}

function Get-LogsIngestionUri {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string] $IngestionEndpoint,

        [Parameter(Mandatory)]
        [string] $DcrImmutableId,

        [Parameter(Mandatory)]
        [string] $StreamName
    )

    $endpoint = $IngestionEndpoint.TrimEnd('/')
    $dcrId = [uri]::EscapeDataString($DcrImmutableId)
    $stream = [uri]::EscapeDataString($StreamName)

    return (
        '{0}/dataCollectionRules/{1}/streams/{2}?api-version=2023-01-01' -f
        $endpoint,
        $dcrId,
        $stream
    )
}

function Save-CollectorSpoolBatch {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string] $SpoolDirectory,

        [Parameter(Mandatory)]
        [string] $CollectorName,

        [Parameter(Mandatory)]
        [string] $IngestionEndpoint,

        [Parameter(Mandatory)]
        [string] $DcrImmutableId,

        [Parameter(Mandatory)]
        [string] $StreamName,

        [Parameter(Mandatory)]
        [string] $PayloadJson
    )

    if (-not (Test-Path -LiteralPath $SpoolDirectory)) {
        New-Item -Path $SpoolDirectory -ItemType Directory -Force | Out-Null
    }

    $spoolObject = [ordered]@{
        SchemaVersion    = '1.0'
        CollectorName    = $CollectorName
        CreatedUtc       = Get-UtcIso8601
        IngestionEndpoint = $IngestionEndpoint
        DcrImmutableId   = $DcrImmutableId
        StreamName       = $StreamName
        Payload          = $PayloadJson
    }

    $fileName = '{0}-{1}-{2}.json' -f `
        $CollectorName,
        (Get-Date -Format 'yyyyMMddHHmmssfff'),
        ([guid]::NewGuid().ToString('N'))

    $path = Join-Path $SpoolDirectory $fileName

    $spoolObject |
        ConvertTo-Json -Depth 10 -Compress |
        Set-Content -LiteralPath $path -Encoding UTF8

    return $path
}

function Send-AzureMonitorRecords {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string] $CollectorName,

        [Parameter(Mandatory)]
        [string] $IngestionEndpoint,

        [Parameter(Mandatory)]
        [string] $DcrImmutableId,

        [Parameter(Mandatory)]
        [string] $StreamName,

        [Parameter(Mandatory)]
        [object[]] $Records,

        [Parameter(Mandatory)]
        [pscustomobject] $SharedSettings,

        [string] $SpoolDirectory,

        [string] $LogDirectory,

        [string] $ExecutionId
    )

    if ($Records.Count -eq 0) {
        return 0
    }

    $maxRecords = [int]$SharedSettings.Ingestion.MaximumRecordsPerBatch
    $maxPayloadBytes = [int]$SharedSettings.Ingestion.MaximumPayloadBytes
    $maximumAttempts = [int]$SharedSettings.Ingestion.MaximumAttempts
    $baseDelaySeconds = [int]$SharedSettings.Ingestion.RetryBaseDelaySeconds

    $uri = Get-LogsIngestionUri `
        -IngestionEndpoint $IngestionEndpoint `
        -DcrImmutableId $DcrImmutableId `
        -StreamName $StreamName

    $batches = [System.Collections.Generic.List[object]]::new()
    $batch = [System.Collections.Generic.List[object]]::new()
    $estimatedBytes = 2

    foreach ($record in $Records) {
        $recordJson = $record | ConvertTo-Json -Depth 12 -Compress
        $recordBytes = [Text.Encoding]::UTF8.GetByteCount($recordJson) + 1

        if ($recordBytes -gt $maxPayloadBytes) {
            throw 'A single record is larger than the configured ingestion payload limit.'
        }

        $newBatchRequired =
            $batch.Count -ge $maxRecords -or
            (($estimatedBytes + $recordBytes) -gt $maxPayloadBytes)

        if ($newBatchRequired -and $batch.Count -gt 0) {
            $batches.Add($batch.ToArray())
            $batch = [System.Collections.Generic.List[object]]::new()
            $estimatedBytes = 2
        }

        $batch.Add($record)
        $estimatedBytes += $recordBytes
    }

    if ($batch.Count -gt 0) {
        $batches.Add($batch.ToArray())
    }

    $submitted = 0

    foreach ($currentBatch in $batches) {
        $payload = ConvertTo-Json -InputObject @($currentBatch) -Depth 12 -Compress
        $attempt = 0
        $delivered = $false

        while (-not $delivered -and $attempt -lt $maximumAttempts) {
            $attempt++

            try {
                $token = Get-ArcManagedIdentityAccessToken `
                    -Resource $SharedSettings.ArcManagedIdentity.TokenResource `
                    -ApiVersion $SharedSettings.ArcManagedIdentity.TokenApiVersion

                Invoke-RestMethod `
                    -Method Post `
                    -Uri $uri `
                    -Headers @{ Authorization = "Bearer $token" } `
                    -ContentType 'application/json; charset=utf-8' `
                    -Body ([Text.Encoding]::UTF8.GetBytes($payload)) `
                    -TimeoutSec 60 `
                    -ErrorAction Stop | Out-Null

                $submitted += $currentBatch.Count
                $delivered = $true

                if ($LogDirectory) {
                    Write-CollectorLog `
                        -LogDirectory $LogDirectory `
                        -Level Information `
                        -ExecutionId $ExecutionId `
                        -Message (
                            "Submitted $($currentBatch.Count) records to stream '$StreamName'."
                        )
                }
            }
            catch {
                $isLastAttempt = $attempt -ge $maximumAttempts

                if ($LogDirectory) {
                    Write-CollectorLog `
                        -LogDirectory $LogDirectory `
                        -Level Warning `
                        -ExecutionId $ExecutionId `
                        -Message (
                            "Ingestion attempt $attempt of $maximumAttempts failed for stream " +
                            "'$StreamName'. Error: $($_.Exception.Message)"
                        )
                }

                if ($isLastAttempt) {
                    break
                }

                $delay = [Math]::Min(60, $baseDelaySeconds * [Math]::Pow(2, $attempt - 1))
                Start-Sleep -Seconds $delay
            }
        }

        if (-not $delivered) {
            if ([bool]$SharedSettings.Ingestion.EnableLocalSpool -and $SpoolDirectory) {
                $spoolPath = Save-CollectorSpoolBatch `
                    -SpoolDirectory $SpoolDirectory `
                    -CollectorName $CollectorName `
                    -IngestionEndpoint $IngestionEndpoint `
                    -DcrImmutableId $DcrImmutableId `
                    -StreamName $StreamName `
                    -PayloadJson $payload

                if ($LogDirectory) {
                    Write-CollectorLog `
                        -LogDirectory $LogDirectory `
                        -Level Error `
                        -ExecutionId $ExecutionId `
                        -Message (
                            "Ingestion failed after retries. Batch was spooled to '$spoolPath'."
                        )
                }
            }
            else {
                throw "Ingestion failed after $maximumAttempts attempts and spooling is disabled."
            }
        }
    }

    return $submitted
}

function Submit-CollectorSpoolBatches {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string] $SpoolDirectory,

        [Parameter(Mandatory)]
        [pscustomobject] $SharedSettings,

        [string] $LogDirectory,

        [string] $ExecutionId
    )

    if (-not (Test-Path -LiteralPath $SpoolDirectory)) {
        return 0
    }

    $submittedFiles = 0

    foreach ($spoolFile in (Get-ChildItem -LiteralPath $SpoolDirectory -File -Filter '*.json' |
            Sort-Object LastWriteTimeUtc)) {
        try {
            $spool = Get-Content -LiteralPath $spoolFile.FullName -Raw -Encoding UTF8 |
                ConvertFrom-Json -ErrorAction Stop

            $uri = Get-LogsIngestionUri `
                -IngestionEndpoint $spool.IngestionEndpoint `
                -DcrImmutableId $spool.DcrImmutableId `
                -StreamName $spool.StreamName

            $token = Get-ArcManagedIdentityAccessToken `
                -Resource $SharedSettings.ArcManagedIdentity.TokenResource `
                -ApiVersion $SharedSettings.ArcManagedIdentity.TokenApiVersion

            Invoke-RestMethod `
                -Method Post `
                -Uri $uri `
                -Headers @{ Authorization = "Bearer $token" } `
                -ContentType 'application/json; charset=utf-8' `
                -Body ([Text.Encoding]::UTF8.GetBytes([string]$spool.Payload)) `
                -TimeoutSec 60 `
                -ErrorAction Stop | Out-Null

            Remove-Item -LiteralPath $spoolFile.FullName -Force
            $submittedFiles++

            if ($LogDirectory) {
                Write-CollectorLog `
                    -LogDirectory $LogDirectory `
                    -Level Information `
                    -ExecutionId $ExecutionId `
                    -Message "Successfully replayed spool file '$($spoolFile.Name)'."
            }
        }
        catch {
            if ($LogDirectory) {
                Write-CollectorLog `
                    -LogDirectory $LogDirectory `
                    -Level Warning `
                    -ExecutionId $ExecutionId `
                    -Message (
                        "Could not replay spool file '$($spoolFile.Name)'. " +
                        "Error: $($_.Exception.Message)"
                    )
            }
        }
    }

    return $submittedFiles
}

function New-CollectorHealthRecord {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string] $CollectorName,

        [Parameter(Mandatory)]
        [string] $ExecutionId,

        [Parameter(Mandatory)]
        [datetime] $StartedUtc,

        [Parameter(Mandatory)]
        [ValidateSet('Success', 'PartialSuccess', 'Failed')]
        [string] $Status,

        [long] $RecordsCollected = 0,

        [long] $RecordsSubmitted = 0,

        [string] $TargetScope,

        [string] $ErrorCode,

        [string] $ErrorMessage,

        [string] $CollectorVersion = '1.0.0'
    )

    $completedUtc = (Get-Date).ToUniversalTime()

    return [pscustomobject]@{
        TimeGenerated    = $completedUtc.ToString('o')
        CollectorName    = $CollectorName
        Computer         = $env:COMPUTERNAME
        TargetScope      = $TargetScope
        ExecutionId      = $ExecutionId
        RecordsCollected = $RecordsCollected
        RecordsSubmitted = $RecordsSubmitted
        DurationSeconds  = [Math]::Round(
            ($completedUtc - $StartedUtc).TotalSeconds,
            3
        )
        Status           = $Status
        ErrorCode        = $ErrorCode
        ErrorMessage     = $ErrorMessage
        CollectorVersion = $CollectorVersion
    }
}

Export-ModuleMember -Function @(
    'Get-UtcIso8601',
    'Read-CollectorJsonConfiguration',
    'Write-CollectorLog',
    'Remove-CollectorExpiredFiles',
    'Enter-CollectorLock',
    'Exit-CollectorLock',
    'Get-ArcManagedIdentityAccessToken',
    'Send-AzureMonitorRecords',
    'Submit-CollectorSpoolBatches',
    'New-CollectorHealthRecord'
)