$secureParameters = @{
    SubscriptionId                    = '<subscription-id>'
    ResourceGroupName                 = 'rg-erpmon-pilot-cac-001'
    Location                          = 'canadacentral'
    TemplateFile                      = 'C:\Source\erp-hybrid-monitoring\azure\main.bicep'
    ParameterFile                     = 'C:\Source\erp-hybrid-monitoring\azure\parameters\pilot.bicepparam'
    ArcResourceGroupName              = 'rg-arc-onprem-pilot-cac-001'
    CertificateCollectorArcMachineNames = @(
        'ERP-MW-01'
    )
    FolderCollectorArcMachineNames = @(
        'ERP-APP-01'
    )
    ArtifactDirectory                 = 'C:\DeploymentArtifacts\ERP-Monitoring'
    CreateResourceGroup               = $true
}

.\Deploy-Phase2Monitoring.ps1 @secureParameters