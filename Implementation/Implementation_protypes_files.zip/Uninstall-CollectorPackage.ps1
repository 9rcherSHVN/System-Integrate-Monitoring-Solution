[CmdletBinding(SupportsShouldProcess)]
param(
    [string] $CollectorRoot = 'C:\ProgramData\Contoso\AzureMonitorCollectors',

    [switch] $RemoveOperationalLogsAndSpool
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$taskNames = @(
    'Contoso-Monitor-CertificateInventory',
    'Contoso-Monitor-ErpFolderMetrics',
    'Contoso-Monitor-CertificateInventory-SpoolReplay',
    'Contoso-Monitor-ErpFolderMetrics-SpoolReplay'
)

foreach ($taskName in $taskNames) {
    if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
        if ($PSCmdlet.ShouldProcess($taskName, 'Unregister scheduled task')) {
            Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
        }
    }
}

foreach ($directory in @(
    (Join-Path $CollectorRoot 'Current'),
    (Join-Path $CollectorRoot 'Previous'),
    (Join-Path $CollectorRoot 'Staging'),
    (Join-Path $CollectorRoot 'Locks')
)) {
    if (Test-Path -LiteralPath $directory) {
        if ($PSCmdlet.ShouldProcess($directory, 'Remove collector package content')) {
            Remove-Item -LiteralPath $directory -Recurse -Force
        }
    }
}

if ($RemoveOperationalLogsAndSpool) {
    foreach ($directory in @(
        (Join-Path $CollectorRoot 'Logs'),
        (Join-Path $CollectorRoot 'Spool')
    )) {
        if (Test-Path -LiteralPath $directory) {
            if ($PSCmdlet.ShouldProcess($directory, 'Remove operational logs and spool files')) {
                Remove-Item -LiteralPath $directory -Recurse -Force
            }
        }
    }
}

Write-Output 'Collector package uninstallation completed.'