$scriptRoot = Split-Path -Path $PSScriptRoot -Parent
$collectorPath = Join-Path $scriptRoot 'collectors'

$results = Invoke-ScriptAnalyzer `
    -Path $collectorPath `
    -Recurse `
    -Severity Error, Warning

if ($results) {
    $results | Format-Table -AutoSize | Out-String | Write-Error
    throw 'PowerShell static analysis failed.'
}

Write-Output 'PowerShell static analysis passed.'