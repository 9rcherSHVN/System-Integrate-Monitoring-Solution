Set-StrictMode -Version Latest

function Get-ArcManagedIdentityAccessToken {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string] $Resource = 'https://monitor.azure.com/',

        [string] $ApiVersion = '2020-06-01'
    )

    if ([string]::IsNullOrWhiteSpace($env:IDENTITY_ENDPOINT)) {
        throw (
            'IDENTITY_ENDPOINT is unavailable. Confirm that this server is Azure Arc-enabled ' +
            'and that its system-assigned managed identity is enabled.'
        )
    }

    $identityEndpoint = [uri]$env:IDENTITY_ENDPOINT

    if (-not $identityEndpoint.IsLoopback) {
        throw 'IDENTITY_ENDPOINT must resolve to a local loopback endpoint.'
    }

    $escapedResource = [uri]::EscapeDataString($Resource)
    $tokenUri = (
        '{0}?resource={1}&api-version={2}' -f
        $identityEndpoint.AbsoluteUri,
        $escapedResource,
        $ApiVersion
    )

    try {
        $response = Invoke-RestMethod `
            -Method Get `
            -Uri $tokenUri `
            -Headers @{ Metadata = 'True' } `
            -TimeoutSec 30 `
            -ErrorAction Stop
    }
    catch {
        throw "Unable to obtain Azure Arc managed identity token. $($_.Exception.Message)"
    }

    if ([string]::IsNullOrWhiteSpace($response.access_token)) {
        throw 'Azure Arc managed identity response did not contain an access token.'
    }

    return [string]$response.access_token
}

Export-ModuleMember -Function Get-ArcManagedIdentityAccessToken