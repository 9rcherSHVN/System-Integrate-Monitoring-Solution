@description('Azure region for the Workbook resource.')
param location string

@description('Log Analytics Workspace resource ID.')
param workspaceResourceId string

@description('Workbook display name.')
param workbookDisplayName string = 'ERP Certificate Monitoring'

@description('Workbook serialized JSON definition.')
param workbookSerializedData string

resource certificateWorkbook 'Microsoft.Insights/workbooks@2022-04-01' = {
  name: guid(workspaceResourceId, workbookDisplayName)
  location: location
  kind: 'shared'
  properties: {
    displayName: workbookDisplayName
    serializedData: workbookSerializedData
    sourceId: workspaceResourceId
    category: 'workbook'
  }
}

output workbookResourceId string = certificateWorkbook.id