param(
    [Parameter(Mandatory)]
    [string] $ResourceGroupName,

    [Parameter(Mandatory)]
    [string] $TemplateFile,

    [Parameter(Mandatory)]
    [string] $ParameterFile
)

az deployment group what-if `
    --resource-group $ResourceGroupName `
    --template-file $TemplateFile `
    --parameters $ParameterFile `
    --result-format FullResourcePayloads