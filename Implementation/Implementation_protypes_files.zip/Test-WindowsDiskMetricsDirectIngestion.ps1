[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string] $IngestionEndpoint,

    [Parameter(Mandatory)]
    [string] $DcrImmutableId,

    [string] $StreamName = 'Custom-WindowsDiskMetricsRaw'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$collectorRoot = 'C:\ProgramData\Contoso\AzureMonitorCollectors\Current'
$modulePath = Join-Path $collectorRoot 'Modules\AzureMonitorCollector.Common.psm1'

Import-Module $modulePath -Force

$record = [pscustomobject]@{
    TimeGenerated          = (Get-Date).ToUniversalTime().ToString('o')
    Computer               = $env:COMPUTERNAME
    Environment            = 'Pilot'
    Application            = 'ERP'
    Drive                  = 'D:'
    VolumeLabel            = 'Validation'
    FileSystem             = 'NTFS'
    TotalBytes             = [Int64]107374182400
    FreeBytes              = [Int64]53687091200
    UsedBytes              = [Int64]53687091200
    TotalGB                = [double]100
    FreeGB                 = [double]50
    UsedGB                 = [double]50
    FreePercent            = [double]50
    UsedPercent            = [double]50
    ReadLatencyMs          = [double]2.1
    WriteLatencyMs         = [double]4.2
    DiskQueueLength        = [double]0.3
    DiskTransfersPerSecond = [double]75
    CollectionStatus       = 'Validation'
    CollectorVersion       = '1.0.0'
}

$settings = [pscustomobject]@{
    ArcManagedIdentity = [pscustomobject]@{
        TokenResource = 'https://monitor.azure.com/'
        TokenApiVersion = '2020-06-01'
    }
    Ingestion = [pscustomobject]@{
        MaximumRecordsPerBatch = 500
        MaximumPayloadBytes = 900000
        MaximumAttempts = 1
        RetryBaseDelaySeconds = 1
        EnableLocalSpool = $false
        SpoolRetentionDays = 1
    }
}

Send-AzureMonitorRecords `
    -CollectorName 'WindowsDiskMetricsValidation' `
    -IngestionEndpoint $IngestionEndpoint `
    -DcrImmutableId $DcrImmutableId `
    -StreamName $StreamName `
    -Records @($record) `
    -SharedSettings $settings `
    -SpoolDirectory 'C:\Temp' `
    -LogDirectory 'C:\Temp' `
    -ExecutionId ([guid]::NewGuid().ToString()) | Out-Null

Write-Output 'Windows disk metrics validation record accepted by Azure Monitor.'