resource windowsDiskMetricsDcrRoleAssignments 'Microsoft.Authorization/roleAssignments@2022-04-01' = [
  for principalId in windowsDiskMetricsCollectorPrincipalIds: {
    name: guid(
      windowsDiskMetricsDcrResourceId
      principalId
      monitoringMetricsPublisherRoleDefinitionId
    )
    scope: resourceId(
      'Microsoft.Insights/dataCollectionRules'
      last(split(windowsDiskMetricsDcrResourceId, '/'))
    )
    properties: {
      roleDefinitionId: monitoringMetricsPublisherRoleDefinitionId
      principalId: principalId
      principalType: 'ServicePrincipal'
    }
  }
]