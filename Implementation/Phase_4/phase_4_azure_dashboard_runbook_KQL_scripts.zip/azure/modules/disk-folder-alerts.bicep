@description('Azure region for scheduled query rules.')
param location string

@description('Log Analytics Workspace resource ID.')
param workspaceResourceId string

@description('Action Group resource ID.')
param actionGroupResourceId string

@description('Deployment environment.')
param environment string

@description('Prefix used for disk/folder alert resource names.')
param alertNamePrefix string = 'sqra-erpmon-disk'

@description('ERP servers expected to submit folder metrics.')
param expectedErpFolderCollectorHosts array = []

@description('Warning free space percentage threshold.')
param diskWarningFreePercent int = 20

@description('Critical free space percentage threshold.')
param diskCriticalFreePercent int = 10

@description('Warning absolute free capacity threshold in GB.')
param diskWarningFreeGb int = 50

@description('Critical absolute free capacity threshold in GB.')
param diskCriticalFreeGb int = 20

@description('Read or write latency threshold in milliseconds.')
param diskLatencyThresholdMs int = 25

@description('ERP log folder growth threshold in GB over 24 hours.')
param erpFolderGrowthThresholdGb int = 5

var expectedHostsKql = '''
datatable(Computer:string)
[
${join([for host in expectedErpFolderCollectorHosts: '    "${host}"'], ',\n')}
]
'''

var diskCapacityCriticalQuery = '''
Perf
| where TimeGenerated > ago(15m)
| where ObjectName == "LogicalDisk"
| where CounterName in ("% Free Space", "Free Megabytes")
| where InstanceName != "_Total"
| summarize arg_max(TimeGenerated, CounterValue) by Computer, InstanceName, CounterName
| evaluate pivot(CounterName, max(CounterValue))
| extend FreePercent = round(todouble(["% Free Space"]), 2)
| extend FreeGB = round(todouble(["Free Megabytes"]) / 1024, 2)
| where FreePercent < ${diskCriticalFreePercent} or FreeGB < ${diskCriticalFreeGb}
| project Computer, Drive = InstanceName, FreePercent, FreeGB
'''

var diskCapacityWarningQuery = '''
Perf
| where TimeGenerated > ago(30m)
| where ObjectName == "LogicalDisk"
| where CounterName in ("% Free Space", "Free Megabytes")
| where InstanceName != "_Total"
| summarize arg_max(TimeGenerated, CounterValue) by Computer, InstanceName, CounterName
| evaluate pivot(CounterName, max(CounterValue))
| extend FreePercent = round(todouble(["% Free Space"]), 2)
| extend FreeGB = round(todouble(["Free Megabytes"]) / 1024, 2)
| where FreePercent >= ${diskCriticalFreePercent} and FreeGB >= ${diskCriticalFreeGb}
| where FreePercent < ${diskWarningFreePercent} or FreeGB < ${diskWarningFreeGb}
| project Computer, Drive = InstanceName, FreePercent, FreeGB
'''

var diskLatencyQuery = '''
Perf
| where TimeGenerated > ago(30m)
| where ObjectName == "LogicalDisk"
| where CounterName in ("Avg. Disk sec/Read", "Avg. Disk sec/Write")
| where InstanceName != "_Total"
| summarize AverageValue = avg(CounterValue) by Computer, InstanceName, CounterName
| evaluate pivot(CounterName, max(AverageValue))
| extend ReadLatencyMs = round(todouble(["Avg. Disk sec/Read"]) * 1000, 2)
| extend WriteLatencyMs = round(todouble(["Avg. Disk sec/Write"]) * 1000, 2)
| where ReadLatencyMs > ${diskLatencyThresholdMs} or WriteLatencyMs > ${diskLatencyThresholdMs}
| project Computer, Drive = InstanceName, ReadLatencyMs, WriteLatencyMs
'''

var erpFolderGrowthQuery = '''
let CurrentMetrics =
    ErpFolderMetrics_CL
    | where TimeGenerated > ago(2h)
    | summarize arg_max(TimeGenerated, TotalBytes, TotalGB, FileCount, CollectionStatus)
        by Computer, Application, FolderPath;
let PreviousMetrics =
    ErpFolderMetrics_CL
    | where TimeGenerated between (ago(26h) .. ago(22h))
    | summarize arg_max(TimeGenerated, TotalBytes, TotalGB, FileCount)
        by Computer, Application, FolderPath;
CurrentMetrics
| join kind=leftouter PreviousMetrics
    on Computer, Application, FolderPath
| extend GrowthBytes24h = TotalBytes - TotalBytes1
| extend GrowthGB24h = round(todouble(GrowthBytes24h) / 1024 / 1024 / 1024, 2)
| where GrowthGB24h >= ${erpFolderGrowthThresholdGb}
| project Computer, Application, FolderPath, TotalGB, GrowthGB24h, FileCount, CollectionStatus
'''

var erpRetentionRiskQuery = '''
ErpFolderMetrics_CL
| where TimeGenerated > ago(6h)
| summarize arg_max(TimeGenerated, *) by Computer, Application, FolderPath
| where CollectionStatus in ("Success", "PartialSuccess")
| where FilesOlderThanRetention > 0
| project Computer, Application, FolderPath, TotalGB, FileCount, FilesOlderThanRetention, RetentionDays, OldestFileUtc, AccessErrorCount
'''

var erpFolderCollectorFailureQuery = '''
CollectorHealth_CL
| where TimeGenerated > ago(2h)
| where CollectorName == "ErpFolderMetrics"
| summarize arg_max(TimeGenerated, *) by Computer, CollectorName
| where Status != "Success"
| project Computer, Status, TargetScope, RecordsCollected, RecordsSubmitted, DurationSeconds, ErrorCode, ErrorMessage
'''

var erpFolderMetricsMissingQuery = '''
let ExpectedErpFolderCollectorHosts = ${expectedHostsKql};
ExpectedErpFolderCollectorHosts
| join kind=leftouter (
    ErpFolderMetrics_CL
    | where TimeGenerated > ago(2h)
    | summarize LastFolderMetric = max(TimeGenerated) by Computer
) on Computer
| where isempty(LastFolderMetric) or LastFolderMetric < ago(2h)
| project Computer, LastFolderMetric, Status = "ERP folder metrics missing or stale"
'''

resource diskCapacityCriticalAlert 'Microsoft.Insights/scheduledQueryRules@2023-12-01' = {
  name: '${alertNamePrefix}-capacity-critical-${environment}-001'
  location: location
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    AlertDomain: 'DiskCapacity'
    Severity: 'Sev1'
  }
  properties: {
    displayName: 'ERP Server Disk Capacity Critical'
    description: 'A monitored ERP server volume is below the configured critical free-space threshold.'
    enabled: true
    scopes: [
      workspaceResourceId
    ]
    severity: 1
    evaluationFrequency: 'PT5M'
    windowSize: 'PT15M'
    autoMitigate: true
    muteActionsDuration: 'PT1H'
    criteria: {
      allOf: [
        {
          query: diskCapacityCriticalQuery
          timeAggregation: 'Count'
          operator: 'GreaterThan'
          threshold: 0
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: [
        actionGroupResourceId
      ]
      customProperties: {
        Service = 'ERP Disk Monitoring'
        Runbook = 'Identify volume owner, stop uncontrolled growth, archive or clear approved data, and extend capacity if required.'
      }
    }
  }
}

resource diskCapacityWarningAlert 'Microsoft.Insights/scheduledQueryRules@2023-12-01' = {
  name: '${alertNamePrefix}-capacity-warning-${environment}-001'
  location: location
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    AlertDomain: 'DiskCapacity'
    Severity: 'Sev2'
  }
  properties: {
    displayName: 'ERP Server Disk Capacity Warning'
    description: 'A monitored ERP server volume is below the configured warning free-space threshold.'
    enabled: true
    scopes: [
      workspaceResourceId
    ]
    severity: 2
    evaluationFrequency: 'PT15M'
    windowSize: 'PT30M'
    autoMitigate: true
    muteActionsDuration: 'PT6H'
    criteria: {
      allOf: [
        {
          query: diskCapacityWarningQuery
          timeAggregation: 'Count'
          operator: 'GreaterThan'
          threshold: 0
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: [
        actionGroupResourceId
      ]
      customProperties: {
        Service = 'ERP Disk Monitoring'
        Runbook = 'Review disk and ERP log growth trend; plan cleanup, retention, archival, or capacity expansion.'
      }
    }
  }
}

resource diskLatencyAlert 'Microsoft.Insights/scheduledQueryRules@2023-12-01' = {
  name: '${alertNamePrefix}-latency-${environment}-001'
  location: location
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    AlertDomain: 'DiskPerformance'
    Severity: 'Sev2'
  }
  properties: {
    displayName: 'ERP Server Disk Latency High'
    description: 'A monitored ERP server volume has sustained read or write latency above the initial threshold.'
    enabled: true
    scopes: [
      workspaceResourceId
    ]
    severity: 2
    evaluationFrequency: 'PT15M'
    windowSize: 'PT30M'
    autoMitigate: true
    muteActionsDuration: 'PT6H'
    criteria: {
      allOf: [
        {
          query: diskLatencyQuery
          timeAggregation: 'Count'
          operator: 'GreaterThan'
          threshold: 0
          failingPeriods: {
            numberOfEvaluationPeriods: 2
            minFailingPeriodsToAlert: 2
          }
        }
      ]
    }
    actions: {
      actionGroups: [
        actionGroupResourceId
      ]
      customProperties: {
        Service = 'ERP Disk Monitoring'
        Runbook = 'Correlate disk latency with ERP response time, CPU, memory, antivirus activity, backup jobs, and SQL I/O where applicable.'
      }
    }
  }
}

resource erpFolderGrowthAlert 'Microsoft.Insights/scheduledQueryRules@2023-12-01' = {
  name: '${alertNamePrefix}-foldergrowth-${environment}-001'
  location: location
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    AlertDomain: 'ErpLogGrowth'
    Severity: 'Sev2'
  }
  properties: {
    displayName: 'ERP Log Folder Growth High'
    description: 'An approved ERP log directory has exceeded the configured 24-hour growth threshold.'
    enabled: true
    scopes: [
      workspaceResourceId
    ]
    severity: 2
    evaluationFrequency: 'PT1H'
    windowSize: 'P1D'
    autoMitigate: true
    muteActionsDuration: 'PT12H'
    criteria: {
      allOf: [
        {
          query: erpFolderGrowthQuery
          timeAggregation: 'Count'
          operator: 'GreaterThan'
          threshold: 0
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: [
        actionGroupResourceId
      ]
      customProperties: {
        Service = 'ERP Log Monitoring'
        Runbook = 'Identify abnormal ERP log production, preserve required evidence, apply approved retention/archival process, and validate free disk capacity.'
      }
    }
  }
}

resource erpRetentionRiskAlert 'Microsoft.Insights/scheduledQueryRules@2023-12-01' = {
  name: '${alertNamePrefix}-retention-${environment}-001'
  location: location
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    AlertDomain: 'ErpLogRetention'
    Severity: 'Sev3'
  }
  properties: {
    displayName: 'ERP Log Retention Accumulation'
    description: 'An ERP log directory contains files older than the configured retention policy.'
    enabled: true
    scopes: [
      workspaceResourceId
    ]
    severity: 3
    evaluationFrequency: 'PT6H'
    windowSize: 'PT6H'
    autoMitigate: true
    muteActionsDuration: 'P1D'
    criteria: {
      allOf: [
        {
          query: erpRetentionRiskQuery
          timeAggregation: 'Count'
          operator: 'GreaterThan'
          threshold: 0
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: [
        actionGroupResourceId
      ]
      customProperties: {
        Service = 'ERP Log Monitoring'
        Runbook = 'Review retention policy, legal hold requirements, archive status, and approved log cleanup procedure.'
      }
    }
  }
}

resource erpFolderCollectorFailureAlert 'Microsoft.Insights/scheduledQueryRules@2023-12-01' = {
  name: '${alertNamePrefix}-collectorfailure-${environment}-001'
  location: location
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    AlertDomain: 'MonitoringHealth'
    Severity: 'Sev2'
  }
  properties: {
    displayName: 'ERP Folder Metrics Collector Failed'
    description: 'The custom ERP folder metrics collector reported failure or partial failure.'
    enabled: true
    scopes: [
      workspaceResourceId
    ]
    severity: 2
    evaluationFrequency: 'PT30M'
    windowSize: 'PT2H'
    autoMitigate: true
    muteActionsDuration: 'PT2H'
    criteria: {
      allOf: [
        {
          query: erpFolderCollectorFailureQuery
          timeAggregation: 'Count'
          operator: 'GreaterThan'
          threshold: 0
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: [
        actionGroupResourceId
      ]
      customProperties: {
        Service = 'ERP Monitoring Health'
        Runbook = 'Review scheduled-task history, local collector log, spool directory, Arc managed identity, DCR authorization, and ERP log-folder permissions.'
      }
    }
  }
}

resource erpFolderMetricsMissingAlert 'Microsoft.Insights/scheduledQueryRules@2023-12-01' = {
  name: '${alertNamePrefix}-metricsmissing-${environment}-001'
  location: location
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    AlertDomain: 'MonitoringHealth'
    Severity: 'Sev2'
  }
  properties: {
    displayName: 'ERP Folder Metrics Missing or Stale'
    description: 'An expected ERP server has not submitted folder metrics within the expected collection window.'
    enabled: true
    scopes: [
      workspaceResourceId
    ]
    severity: 2
    evaluationFrequency: 'PT30M'
    windowSize: 'PT2H'
    autoMitigate: true
    muteActionsDuration: 'PT2H'
    criteria: {
      allOf: [
        {
          query: erpFolderMetricsMissingQuery
          timeAggregation: 'Count'
          operator: 'GreaterThan'
          threshold: 0
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: [
        actionGroupResourceId
      ]
      customProperties: {
        Service = 'ERP Monitoring Health'
        Runbook = 'Confirm collector task status, run-as account access, Azure Arc identity token availability, and Log Analytics ingestion status.'
      }
    }
  }
}

output diskCapacityCriticalAlertResourceId string = diskCapacityCriticalAlert.id
output diskCapacityWarningAlertResourceId string = diskCapacityWarningAlert.id
output diskLatencyAlertResourceId string = diskLatencyAlert.id
output erpFolderGrowthAlertResourceId string = erpFolderGrowthAlert.id
output erpRetentionRiskAlertResourceId string = erpRetentionRiskAlert.id
output erpFolderCollectorFailureAlertResourceId string = erpFolderCollectorFailureAlert.id
output erpFolderMetricsMissingAlertResourceId string = erpFolderMetricsMissingAlert.id