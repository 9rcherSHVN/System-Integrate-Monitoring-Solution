@description('Azure region for scheduled query rules.')
param location string

@description('Log Analytics Workspace resource ID.')
param workspaceResourceId string

@description('Action Group resource ID.')
param actionGroupResourceId string

@description('Deployment environment.')
param environment string

@description('Prefix used for alert resource names.')
param alertNamePrefix string = 'sqra-erpmon-cert'

var evaluationFrequency = 'PT6H'
var windowSize = 'PT30H'

var expiredCertificatesQuery = '''
ServerCertificateInventory_CL
| where TimeGenerated > ago(30h)
| summarize arg_max(TimeGenerated, *) by Computer, StoreLocation, StoreName, Thumbprint
| where CollectionStatus == "Success"
| where DaysUntilExpiry < 0 or NotAfter < now()
| project Computer, StoreName, Subject, DnsNames, NotAfter, DaysUntilExpiry, IisBindings, Thumbprint
'''

var expiringWithinSevenDaysQuery = '''
ServerCertificateInventory_CL
| where TimeGenerated > ago(30h)
| summarize arg_max(TimeGenerated, *) by Computer, StoreLocation, StoreName, Thumbprint
| where CollectionStatus == "Success"
| where DaysUntilExpiry between (0 .. 7)
| project Computer, StoreName, Subject, DnsNames, NotAfter, DaysUntilExpiry, IisBindings, Thumbprint
'''

var expiringWithinFourteenDaysQuery = '''
ServerCertificateInventory_CL
| where TimeGenerated > ago(30h)
| summarize arg_max(TimeGenerated, *) by Computer, StoreLocation, StoreName, Thumbprint
| where CollectionStatus == "Success"
| where DaysUntilExpiry between (8 .. 14)
| project Computer, StoreName, Subject, DnsNames, NotAfter, DaysUntilExpiry, IisBindings, Thumbprint
'''

var expiringWithinThirtyDaysQuery = '''
ServerCertificateInventory_CL
| where TimeGenerated > ago(30h)
| summarize arg_max(TimeGenerated, *) by Computer, StoreLocation, StoreName, Thumbprint
| where CollectionStatus == "Success"
| where DaysUntilExpiry between (15 .. 30)
| project Computer, StoreName, Subject, DnsNames, NotAfter, DaysUntilExpiry, IisBindings, Thumbprint
'''

var missingPrivateKeyQuery = '''
ServerCertificateInventory_CL
| where TimeGenerated > ago(30h)
| summarize arg_max(TimeGenerated, *) by Computer, StoreLocation, StoreName, Thumbprint
| where CollectionStatus == "Success"
| where StoreLocation == "LocalMachine" and StoreName == "WebHosting"
| where HasPrivateKey == false
| where isnotempty(IisBindings)
| project Computer, StoreName, Subject, DnsNames, NotAfter, DaysUntilExpiry, IisBindings, Thumbprint
'''

var certificateCollectorFailureQuery = '''
CollectorHealth_CL
| where TimeGenerated > ago(30h)
| where CollectorName == "CertificateInventory"
| summarize arg_max(TimeGenerated, *) by Computer, CollectorName
| where Status != "Success"
| project Computer, Status, ErrorCode, ErrorMessage, RecordsCollected, RecordsSubmitted, DurationSeconds
'''

resource expiredCertificatesAlert 'Microsoft.Insights/scheduledQueryRules@2023-12-01' = {
  name: '${alertNamePrefix}-expired-${environment}-001'
  location: location
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    AlertDomain: 'Certificate'
    Severity: 'Sev1'
  }
  properties: {
    displayName: 'ERP Certificate Expired'
    description: 'A WebHosting certificate used by the ERP monitoring scope has expired.'
    enabled: true
    scopes: [
      workspaceResourceId
    ]
    severity: 1
    evaluationFrequency: evaluationFrequency
    windowSize: windowSize
    autoMitigate: true
    muteActionsDuration: 'PT6H'
    criteria: {
      allOf: [
        {
          query: expiredCertificatesQuery
          timeAggregation: 'Count'
          operator: 'GreaterThan'
          threshold: 0
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: [
        actionGroupResourceId
      ]
      customProperties: {
        Service = 'ERP Certificate Monitoring'
        Runbook = 'Renew or replace expired certificate and validate IIS HTTPS binding.'
      }
    }
  }
}

resource expiringSevenDaysAlert 'Microsoft.Insights/scheduledQueryRules@2023-12-01' = {
  name: '${alertNamePrefix}-7days-${environment}-001'
  location: location
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    AlertDomain: 'Certificate'
    Severity: 'Sev2'
  }
  properties: {
    displayName: 'ERP Certificate Expires Within 7 Days'
    description: 'A WebHosting certificate used by the ERP monitoring scope expires within seven days.'
    enabled: true
    scopes: [
      workspaceResourceId
    ]
    severity: 2
    evaluationFrequency: evaluationFrequency
    windowSize: windowSize
    autoMitigate: true
    muteActionsDuration: 'PT12H'
    criteria: {
      allOf: [
        {
          query: expiringWithinSevenDaysQuery
          timeAggregation: 'Count'
          operator: 'GreaterThan'
          threshold: 0
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: [
        actionGroupResourceId
      ]
      customProperties: {
        Service = 'ERP Certificate Monitoring'
        Runbook = 'Prioritize certificate renewal and confirm replacement binding before expiry.'
      }
    }
  }
}

resource expiringFourteenDaysAlert 'Microsoft.Insights/scheduledQueryRules@2023-12-01' = {
  name: '${alertNamePrefix}-14days-${environment}-001'
  location: location
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    AlertDomain: 'Certificate'
    Severity: 'Sev2'
  }
  properties: {
    displayName: 'ERP Certificate Expires Within 14 Days'
    description: 'A WebHosting certificate used by the ERP monitoring scope expires within 14 days.'
    enabled: true
    scopes: [
      workspaceResourceId
    ]
    severity: 2
    evaluationFrequency: evaluationFrequency
    windowSize: windowSize
    autoMitigate: true
    muteActionsDuration: 'PT24H'
    criteria: {
      allOf: [
        {
          query: expiringWithinFourteenDaysQuery
          timeAggregation: 'Count'
          operator: 'GreaterThan'
          threshold: 0
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: [
        actionGroupResourceId
      ]
      customProperties: {
        Service = 'ERP Certificate Monitoring'
        Runbook = 'Schedule certificate renewal and test target IIS binding.'
      }
    }
  }
}

resource expiringThirtyDaysAlert 'Microsoft.Insights/scheduledQueryRules@2023-12-01' = {
  name: '${alertNamePrefix}-30days-${environment}-001'
  location: location
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    AlertDomain: 'Certificate'
    Severity: 'Sev3'
  }
  properties: {
    displayName: 'ERP Certificate Expires Within 30 Days'
    description: 'A WebHosting certificate used by the ERP monitoring scope expires within 30 days.'
    enabled: true
    scopes: [
      workspaceResourceId
    ]
    severity: 3
    evaluationFrequency: evaluationFrequency
    windowSize: windowSize
    autoMitigate: true
    muteActionsDuration: 'P1D'
    criteria: {
      allOf: [
        {
          query: expiringWithinThirtyDaysQuery
          timeAggregation: 'Count'
          operator: 'GreaterThan'
          threshold: 0
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: [
        actionGroupResourceId
      ]
      customProperties: {
        Service = 'ERP Certificate Monitoring'
        Runbook = 'Create certificate renewal work item and identify certificate owner.'
      }
    }
  }
}

resource missingPrivateKeyAlert 'Microsoft.Insights/scheduledQueryRules@2023-12-01' = {
  name: '${alertNamePrefix}-privatekey-${environment}-001'
  location: location
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    AlertDomain: 'Certificate'
    Severity: 'Sev2'
  }
  properties: {
    displayName: 'ERP IIS-Bound Certificate Missing Private Key'
    description: 'An IIS-bound certificate in the WebHosting store does not report an associated private key.'
    enabled: true
    scopes: [
      workspaceResourceId
    ]
    severity: 2
    evaluationFrequency: evaluationFrequency
    windowSize: windowSize
    autoMitigate: true
    muteActionsDuration: 'PT12H'
    criteria: {
      allOf: [
        {
          query: missingPrivateKeyQuery
          timeAggregation: 'Count'
          operator: 'GreaterThan'
          threshold: 0
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: [
        actionGroupResourceId
      ]
      customProperties: {
        Service = 'ERP Certificate Monitoring'
        Runbook = 'Validate certificate import, private-key association, and IIS HTTPS binding.'
      }
    }
  }
}

resource collectorFailureAlert 'Microsoft.Insights/scheduledQueryRules@2023-12-01' = {
  name: '${alertNamePrefix}-collectorfailure-${environment}-001'
  location: location
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    AlertDomain: 'MonitoringHealth'
    Severity: 'Sev2'
  }
  properties: {
    displayName: 'ERP Certificate Collector Failed'
    description: 'The certificate inventory collector reported a failure or partial failure.'
    enabled: true
    scopes: [
      workspaceResourceId
    ]
    severity: 2
    evaluationFrequency: evaluationFrequency
    windowSize: windowSize
    autoMitigate: true
    muteActionsDuration: 'PT6H'
    criteria: {
      allOf: [
        {
          query: certificateCollectorFailureQuery
          timeAggregation: 'Count'
          operator: 'GreaterThan'
          threshold: 0
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: [
        actionGroupResourceId
      ]
      customProperties: {
        Service = 'ERP Certificate Monitoring'
        Runbook = 'Review task history, collector local logs, Azure Arc identity, and ingestion configuration.'
      }
    }
  }
}

output expiredCertificatesAlertResourceId string = expiredCertificatesAlert.id
output expiringSevenDaysAlertResourceId string = expiringSevenDaysAlert.id
output expiringFourteenDaysAlertResourceId string = expiringFourteenDaysAlert.id
output expiringThirtyDaysAlertResourceId string = expiringThirtyDaysAlert.id
output missingPrivateKeyAlertResourceId string = missingPrivateKeyAlert.id
output collectorFailureAlertResourceId string = collectorFailureAlert.id