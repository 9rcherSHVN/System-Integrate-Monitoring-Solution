[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string] $SourcePackagePath,

    [string] $CollectorRoot = 'C:\ProgramData\Contoso\AzureMonitorCollectors',

    [Parameter(Mandatory)]
    [string] $CollectorRunAsAccount,

    [switch] $SkipSignatureValidation
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Copy-DirectoryContents {
    param(
        [Parameter(Mandatory)]
        [string] $Source,

        [Parameter(Mandatory)]
        [string] $Destination
    )

    New-Item -Path $Destination -ItemType Directory -Force | Out-Null

    Get-ChildItem -LiteralPath $Source -Force |
        Copy-Item -Destination $Destination -Recurse -Force
}

if (-not (Test-Path -LiteralPath $SourcePackagePath -PathType Container)) {
    throw "Source package path was not found: $SourcePackagePath"
}

$requiredItems = @(
    'Modules',
    'Collectors',
    'Config',
    'Version\release.json'
)

foreach ($item in $requiredItems) {
    $path = Join-Path $SourcePackagePath $item

    if (-not (Test-Path -LiteralPath $path)) {
        throw "Source package is missing required item: $item"
    }
}

$stagingPath = Join-Path $CollectorRoot 'Staging'
$currentPath = Join-Path $CollectorRoot 'Current'
$previousPath = Join-Path $CollectorRoot 'Previous'

foreach ($path in @(
    $CollectorRoot,
    (Join-Path $CollectorRoot 'Logs'),
    (Join-Path $CollectorRoot 'Spool'),
    (Join-Path $CollectorRoot 'Locks')
)) {
    New-Item -Path $path -ItemType Directory -Force | Out-Null
}

Remove-Item -LiteralPath $stagingPath -Recurse -Force -ErrorAction SilentlyContinue
Copy-DirectoryContents -Source $SourcePackagePath -Destination $stagingPath

if (-not $SkipSignatureValidation) {
    $signedFiles = Get-ChildItem `
        -LiteralPath $stagingPath `
        -Recurse `
        -File |
        Where-Object { $_.Extension -in @('.ps1', '.psm1') }

    $invalidSignatures = foreach ($file in $signedFiles) {
        $signature = Get-AuthenticodeSignature -FilePath $file.FullName

        if ($signature.Status -ne 'Valid') {
            [pscustomobject]@{
                Path   = $file.FullName
                Status = $signature.Status
                Detail = $signature.StatusMessage
            }
        }
    }

    if ($invalidSignatures) {
        $invalidSignatures | Format-Table -AutoSize | Out-String | Write-Error
        throw 'Package installation stopped because one or more scripts are unsigned or invalid.'
    }
}

Remove-Item -LiteralPath $previousPath -Recurse -Force -ErrorAction SilentlyContinue

if (Test-Path -LiteralPath $currentPath) {
    Move-Item -LiteralPath $currentPath -Destination $previousPath -Force
}

Move-Item -LiteralPath $stagingPath -Destination $currentPath -Force

$aclTargets = @(
    (Join-Path $CollectorRoot 'Current'),
    (Join-Path $CollectorRoot 'Logs'),
    (Join-Path $CollectorRoot 'Spool'),
    (Join-Path $CollectorRoot 'Locks'),
    (Join-Path $CollectorRoot 'Previous')
)

foreach ($target in $aclTargets) {
    $acl = Get-Acl -LiteralPath $target
    $acl.SetAccessRuleProtection($true, $false)

    $administrators = New-Object System.Security.AccessControl.FileSystemAccessRule(
        'BUILTIN\Administrators',
        'FullControl',
        'ContainerInherit,ObjectInherit',
        'None',
        'Allow'
    )

    $system = New-Object System.Security.AccessControl.FileSystemAccessRule(
        'NT AUTHORITY\SYSTEM',
        'FullControl',
        'ContainerInherit,ObjectInherit',
        'None',
        'Allow'
    )

    $acl.SetAccessRule($administrators)
    $acl.SetAccessRule($system)

    Set-Acl -LiteralPath $target -AclObject $acl
}

$currentAcl = Get-Acl -LiteralPath $currentPath
$currentAcl.AddAccessRule(
    (New-Object System.Security.AccessControl.FileSystemAccessRule(
        $CollectorRunAsAccount,
        'ReadAndExecute',
        'ContainerInherit,ObjectInherit',
        'None',
        'Allow'
    ))
)
Set-Acl -LiteralPath $currentPath -AclObject $currentAcl

foreach ($path in @(
    (Join-Path $CollectorRoot 'Logs'),
    (Join-Path $CollectorRoot 'Spool'),
    (Join-Path $CollectorRoot 'Locks')
)) {
    $acl = Get-Acl -LiteralPath $path
    $acl.AddAccessRule(
        (New-Object System.Security.AccessControl.FileSystemAccessRule(
            $CollectorRunAsAccount,
            'Modify',
            'ContainerInherit,ObjectInherit',
            'None',
            'Allow'
        ))
    )
    Set-Acl -LiteralPath $path -AclObject $acl
}

Write-Output "Collector package installed successfully at: $currentPath"
Write-Output "Previous package, if present: $previousPath"