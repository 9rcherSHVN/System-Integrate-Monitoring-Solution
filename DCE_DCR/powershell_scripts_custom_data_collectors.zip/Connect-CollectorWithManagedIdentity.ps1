Import-Module Az.Accounts
Connect-AzAccount -Identity -ErrorAction Stop | Out-Null