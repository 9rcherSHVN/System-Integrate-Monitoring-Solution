@description('Enable deployment of the certificate-monitoring Workbook.')
param enableCertificateWorkbook bool = true

module certificateWorkbook './modules/certificate-workbook.bicep' = if (enableCertificateWorkbook) {
  name: 'deploy-certificate-workbook'
  params: {
    location: location
    workspaceResourceId: workspace.outputs.workspaceResourceId
    workbookDisplayName: 'ERP Certificate Monitoring'
    workbookSerializedData: loadTextContent('../workbooks/certificate-monitoring.workbook.json')
  }
  dependsOn: [
    tables
  ]
}