param(
    [Parameter(Mandatory)]
    [string] $CollectorRoot
)

$files = Get-ChildItem `
    -Path $CollectorRoot `
    -Recurse `
    -File `
    -Include '*.ps1', '*.psm1'

$invalid = foreach ($file in $files) {
    $signature = Get-AuthenticodeSignature -FilePath $file.FullName

    if ($signature.Status -ne 'Valid') {
        [pscustomobject]@{
            File   = $file.FullName
            Status = $signature.Status
            Detail = $signature.StatusMessage
        }
    }
}

if ($invalid) {
    $invalid | Format-Table -AutoSize | Out-String | Write-Error
    throw 'Collector package contains unsigned or invalidly signed scripts.'
}

Write-Output 'All collector scripts and modules have valid signatures.'