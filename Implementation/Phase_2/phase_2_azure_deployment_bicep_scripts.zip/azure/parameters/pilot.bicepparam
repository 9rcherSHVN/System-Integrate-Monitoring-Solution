using '../main.bicep'

param location = 'canadacentral'

param environment = 'pilot'

param logAnalyticsWorkspaceName = 'law-erpmon-pilot-cac-001'

param dataCollectionEndpointName = 'dce-erpmon-pilot-cac-001'

param certificateDcrName = 'dcr-erpmon-cert-pilot-001'

param folderMetricsDcrName = 'dcr-erpmon-folder-pilot-001'

param collectorHealthDcrName = 'dcr-erpmon-health-pilot-001'

param actionGroupName = 'ag-erpmon-ops-pilot-001'

param operationsEmailAddress = 'erp-platform-support@example.com'

// Replace placeholders with object/principal IDs of the Azure Arc system-assigned
// managed identities for the actual collector hosts.
param certificateCollectorPrincipalIds = [
  '00000000-0000-0000-0000-000000000001'
]

param folderCollectorPrincipalIds = [
  '00000000-0000-0000-0000-000000000002'
]

param healthCollectorPrincipalIds = [
  '00000000-0000-0000-0000-000000000001'
  '00000000-0000-0000-0000-000000000002'
]