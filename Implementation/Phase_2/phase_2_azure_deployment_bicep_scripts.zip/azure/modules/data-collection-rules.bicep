@description('Azure region for DCR resources.')
param location string

@description('Resource ID of the target Log Analytics Workspace.')
param workspaceResourceId string

@description('Resource ID of the Data Collection Endpoint.')
param dataCollectionEndpointResourceId string

@description('Certificate inventory DCR name.')
param certificateDcrName string

@description('ERP folder metrics DCR name.')
param folderMetricsDcrName string

@description('Collector health DCR name.')
param collectorHealthDcrName string

@description('Deployment environment.')
param environment string

resource certificateDcr 'Microsoft.Insights/dataCollectionRules@2023-03-11' = {
  name: certificateDcrName
  location: location
  kind: 'Direct'
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    DataClassification: 'Internal'
    Collector: 'CertificateInventory'
  }
  properties: {
    dataCollectionEndpointId: dataCollectionEndpointResourceId
    streamDeclarations: {
      'Custom-ServerCertificateInventoryRaw': {
        columns: [
          {
            name: 'TimeGenerated'
            type: 'datetime'
          }
          {
            name: 'Computer'
            type: 'string'
          }
          {
            name: 'Environment'
            type: 'string'
          }
          {
            name: 'Application'
            type: 'string'
          }
          {
            name: 'StoreLocation'
            type: 'string'
          }
          {
            name: 'StoreName'
            type: 'string'
          }
          {
            name: 'Subject'
            type: 'string'
          }
          {
            name: 'DnsNames'
            type: 'string'
          }
          {
            name: 'Issuer'
            type: 'string'
          }
          {
            name: 'Thumbprint'
            type: 'string'
          }
          {
            name: 'SerialNumber'
            type: 'string'
          }
          {
            name: 'NotBefore'
            type: 'datetime'
          }
          {
            name: 'NotAfter'
            type: 'datetime'
          }
          {
            name: 'DaysUntilExpiry'
            type: 'long'
          }
          {
            name: 'HasPrivateKey'
            type: 'boolean'
          }
          {
            name: 'EnhancedKeyUsage'
            type: 'string'
          }
          {
            name: 'IisBindings'
            type: 'string'
          }
          {
            name: 'CollectionStatus'
            type: 'string'
          }
          {
            name: 'CollectorVersion'
            type: 'string'
          }
        ]
      }
    }
    destinations: {
      logAnalytics: [
        {
          name: 'certificateWorkspace'
          workspaceResourceId: workspaceResourceId
        }
      ]
    }
    dataFlows: [
      {
        streams: [
          'Custom-ServerCertificateInventoryRaw'
        ]
        destinations: [
          'certificateWorkspace'
        ]
        transformKql: 'source'
        outputStream: 'Custom-ServerCertificateInventory_CL'
      }
    ]
  }
}

resource folderMetricsDcr 'Microsoft.Insights/dataCollectionRules@2023-03-11' = {
  name: folderMetricsDcrName
  location: location
  kind: 'Direct'
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    DataClassification: 'Internal'
    Collector: 'ErpFolderMetrics'
  }
  properties: {
    dataCollectionEndpointId: dataCollectionEndpointResourceId
    streamDeclarations: {
      'Custom-ErpFolderMetricsRaw': {
        columns: [
          {
            name: 'TimeGenerated'
            type: 'datetime'
          }
          {
            name: 'Computer'
            type: 'string'
          }
          {
            name: 'Environment'
            type: 'string'
          }
          {
            name: 'Application'
            type: 'string'
          }
          {
            name: 'FolderPath'
            type: 'string'
          }
          {
            name: 'TotalBytes'
            type: 'long'
          }
          {
            name: 'TotalGB'
            type: 'real'
          }
          {
            name: 'FileCount'
            type: 'long'
          }
          {
            name: 'OldestFileUtc'
            type: 'datetime'
          }
          {
            name: 'NewestFileUtc'
            type: 'datetime'
          }
          {
            name: 'FilesOlderThanRetention'
            type: 'long'
          }
          {
            name: 'RetentionDays'
            type: 'long'
          }
          {
            name: 'AccessErrorCount'
            type: 'long'
          }
          {
            name: 'ScanDurationSeconds'
            type: 'real'
          }
          {
            name: 'CollectionStatus'
            type: 'string'
          }
          {
            name: 'CollectorVersion'
            type: 'string'
          }
        ]
      }
    }
    destinations: {
      logAnalytics: [
        {
          name: 'folderMetricsWorkspace'
          workspaceResourceId: workspaceResourceId
        }
      ]
    }
    dataFlows: [
      {
        streams: [
          'Custom-ErpFolderMetricsRaw'
        ]
        destinations: [
          'folderMetricsWorkspace'
        ]
        transformKql: 'source'
        outputStream: 'Custom-ErpFolderMetrics_CL'
      }
    ]
  }
}

resource collectorHealthDcr 'Microsoft.Insights/dataCollectionRules@2023-03-11' = {
  name: collectorHealthDcrName
  location: location
  kind: 'Direct'
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    DataClassification: 'Internal'
    Collector: 'CollectorHealth'
  }
  properties: {
    dataCollectionEndpointId: dataCollectionEndpointResourceId
    streamDeclarations: {
      'Custom-CollectorHealthRaw': {
        columns: [
          {
            name: 'TimeGenerated'
            type: 'datetime'
          }
          {
            name: 'CollectorName'
            type: 'string'
          }
          {
            name: 'Computer'
            type: 'string'
          }
          {
            name: 'TargetScope'
            type: 'string'
          }
          {
            name: 'ExecutionId'
            type: 'string'
          }
          {
            name: 'RecordsCollected'
            type: 'long'
          }
          {
            name: 'RecordsSubmitted'
            type: 'long'
          }
          {
            name: 'DurationSeconds'
            type: 'real'
          }
          {
            name: 'Status'
            type: 'string'
          }
          {
            name: 'ErrorCode'
            type: 'string'
          }
          {
            name: 'ErrorMessage'
            type: 'string'
          }
          {
            name: 'CollectorVersion'
            type: 'string'
          }
        ]
      }
    }
    destinations: {
      logAnalytics: [
        {
          name: 'collectorHealthWorkspace'
          workspaceResourceId: workspaceResourceId
        }
      ]
    }
    dataFlows: [
      {
        streams: [
          'Custom-CollectorHealthRaw'
        ]
        destinations: [
          'collectorHealthWorkspace'
        ]
        transformKql: 'source'
        outputStream: 'Custom-CollectorHealth_CL'
      }
    ]
  }
}

output certificateDcrResourceId string = certificateDcr.id
output certificateDcrImmutableId string = certificateDcr.properties.immutableId

output folderMetricsDcrResourceId string = folderMetricsDcr.id
output folderMetricsDcrImmutableId string = folderMetricsDcr.properties.immutableId

output collectorHealthDcrResourceId string = collectorHealthDcr.id
output collectorHealthDcrImmutableId string = collectorHealthDcr.properties.immutableId