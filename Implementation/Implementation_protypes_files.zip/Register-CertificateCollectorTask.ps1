$taskName = 'Contoso-Monitor-CertificateInventory'
$collectorRoot = 'C:\ProgramData\Contoso\AzureMonitorCollectors'
$scriptPath = Join-Path $collectorRoot 'Collectors\Collect-CertificateInventory.ps1'

$action = New-ScheduledTaskAction `
    -Execute 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' `
    -Argument (
        '-NoLogo -NoProfile -NonInteractive -ExecutionPolicy AllSigned ' +
        "-File `"$scriptPath`""
    ) `
    -WorkingDirectory $collectorRoot

$trigger = New-ScheduledTaskTrigger -Daily -At 2:15AM

$settings = New-ScheduledTaskSettingsSet `
    -ExecutionTimeLimit (New-TimeSpan -Minutes 15) `
    -MultipleInstances IgnoreNew `
    -RestartCount 3 `
    -RestartInterval (New-TimeSpan -Minutes 15) `
    -StartWhenAvailable

$principal = New-ScheduledTaskPrincipal `
    -UserId '.\svc_AzureMonitorCollector' `
    -LogonType Password `
    -RunLevel LeastPrivilege

Register-ScheduledTask `
    -TaskName $taskName `
    -Action $action `
    -Trigger $trigger `
    -Settings $settings `
    -Principal $principal `
    -Description 'Collects WebHosting certificate inventory and submits telemetry to Azure Monitor.' `
    -Force