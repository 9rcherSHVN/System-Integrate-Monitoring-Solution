@description('Azure region for the Data Collection Rule.')
param location string

@description('Name of the Windows disk-performance DCR.')
param dcrName string

@description('Resource ID of the target Log Analytics Workspace.')
param workspaceResourceId string

@description('Deployment environment.')
param environment string

resource diskPerformanceDcr 'Microsoft.Insights/dataCollectionRules@2023-03-11' = {
  name: dcrName
  location: location
  kind: 'Windows'
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    DataClassification: 'Internal'
    Collector: 'AzureMonitorAgent'
    MonitoringDomain: 'WindowsDisk'
  }
  properties: {
    dataSources: {
      performanceCounters: [
        {
          name: 'erpLogicalDiskCounters'
          streams: [
            'Microsoft-Perf'
          ]
          samplingFrequencyInSeconds: 300
          counterSpecifiers: [
            '\\LogicalDisk(*)\\% Free Space'
            '\\LogicalDisk(*)\\Free Megabytes'
            '\\LogicalDisk(*)\\Avg. Disk sec/Read'
            '\\LogicalDisk(*)\\Avg. Disk sec/Write'
            '\\LogicalDisk(*)\\Current Disk Queue Length'
            '\\LogicalDisk(*)\\Disk Transfers/sec'
          ]
        }
      ]
    }
    destinations: {
      logAnalytics: [
        {
          name: 'erpMonitoringWorkspace'
          workspaceResourceId: workspaceResourceId
        }
      ]
    }
    dataFlows: [
      {
        streams: [
          'Microsoft-Perf'
        ]
        destinations: [
          'erpMonitoringWorkspace'
        ]
      }
    ]
  }
}

output diskPerformanceDcrResourceId string = diskPerformanceDcr.id