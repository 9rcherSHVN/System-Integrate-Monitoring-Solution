[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$collectorRoot = Split-Path -Path $PSScriptRoot -Parent
$modulePath = Join-Path $collectorRoot 'Modules\AzureMonitorCollector.Common.psm1'
$configRoot = Join-Path $collectorRoot 'Config'

Import-Module $modulePath -Force

$sharedSettings = Read-CollectorJsonConfiguration `
    -Path (Join-Path $configRoot 'CollectorSettings.json')

$collectorSettings = Read-CollectorJsonConfiguration `
    -Path (Join-Path $configRoot 'WindowsDiskMetrics.config.json')

if (-not [bool]$collectorSettings.Enabled) {
    Write-Output 'Windows logical-disk collector is disabled by configuration.'
    exit 0
}

$collectorName = [string]$collectorSettings.CollectorName
$executionId = [guid]::NewGuid().ToString()
$startedUtc = (Get-Date).ToUniversalTime()
$logDirectory = Join-Path $sharedSettings.CollectorRoot "Logs\$collectorName"
$spoolDirectory = Join-Path $sharedSettings.CollectorRoot "Spool\$collectorName"
$lockPath = Join-Path $sharedSettings.CollectorRoot "Locks\$collectorName.lock"
$lockHandle = $null

$recordsCollected = 0
$recordsSubmitted = 0
$status = 'Success'
$errorCode = $null
$errorMessage = $null

function Get-LogicalDiskPerformanceSamples {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string[]] $Drives,

        [ValidateRange(1, 10)]
        [int] $SampleIntervalSeconds = 1
    )

    $counterPaths = [System.Collections.Generic.List[string]]::new()

    foreach ($drive in $Drives) {
        $normalizedDrive = $drive.TrimEnd('\').TrimEnd(':')

        foreach ($counterName in @(
            'Avg. Disk sec/Read',
            'Avg. Disk sec/Write',
            'Current Disk Queue Length',
            'Disk Transfers/sec'
        )) {
            $counterPaths.Add("\LogicalDisk($normalizedDrive`:)\$counterName")
        }
    }

    try {
        # Two samples provide a more meaningful rate-based sample for Disk Transfers/sec.
        $counterResult = Get-Counter `
            -Counter $counterPaths.ToArray() `
            -SampleInterval $SampleIntervalSeconds `
            -MaxSamples 2 `
            -ErrorAction Stop

        $latestSample = $counterResult[-1]

        $results = @{}

        foreach ($sample in $latestSample.CounterSamples) {
            $instance = $sample.InstanceName
            $counter = $sample.Path.Split('\')[-1]

            if (-not $results.ContainsKey($instance)) {
                $results[$instance] = @{}
            }

            $results[$instance][$counter] = [double]$sample.CookedValue
        }

        return $results
    }
    catch {
        Write-Warning (
            "Unable to collect one or more LogicalDisk performance counters. " +
            "$($_.Exception.Message)"
        )

        return @{}
    }
}

function Get-PerformanceValue {
    param(
        [hashtable] $PerformanceData,

        [string] $Drive,

        [string] $CounterName
    )

    $instance = $Drive.TrimEnd('\').TrimEnd(':') + ':'

    if ($PerformanceData.ContainsKey($instance) -and
        $PerformanceData[$instance].ContainsKey($CounterName)) {
        return [double]$PerformanceData[$instance][$CounterName]
    }

    return $null
}

try {
    $lockHandle = Enter-CollectorLock -LockPath $lockPath

    Write-CollectorLog `
        -LogDirectory $logDirectory `
        -Level Information `
        -ExecutionId $executionId `
        -Message 'Windows logical-disk metrics collection started.'

    Remove-CollectorExpiredFiles `
        -Directory $logDirectory `
        -RetentionDays ([int]$sharedSettings.Logging.RetentionDays)

    Remove-CollectorExpiredFiles `
        -Directory $spoolDirectory `
        -RetentionDays ([int]$sharedSettings.Ingestion.SpoolRetentionDays)

    Submit-CollectorSpoolBatches `
        -SpoolDirectory $spoolDirectory `
        -SharedSettings $sharedSettings `
        -LogDirectory $logDirectory `
        -ExecutionId $executionId | Out-Null

    $configuredDrives = @(
        $collectorSettings.Drives |
            Where-Object { $_.Enabled } |
            ForEach-Object { [string]$_.Drive }
    )

    if ($configuredDrives.Count -eq 0) {
        throw 'No enabled logical drives are defined in WindowsDiskMetrics.config.json.'
    }

    $performanceData = Get-LogicalDiskPerformanceSamples `
        -Drives $configuredDrives `
        -SampleIntervalSeconds ([int]$collectorSettings.SampleIntervalSeconds)

    $logicalDisks = Get-CimInstance `
        -ClassName Win32_LogicalDisk `
        -Filter 'DriveType = 3' `
        -ErrorAction Stop

    $collectionTime = (Get-Date).ToUniversalTime()
    $records = [System.Collections.Generic.List[object]]::new()

    foreach ($driveDefinition in $collectorSettings.Drives) {
        if (-not [bool]$driveDefinition.Enabled) {
            continue
        }

        $driveName = ([string]$driveDefinition.Drive).TrimEnd('\').TrimEnd(':') + ':'

        $logicalDisk = $logicalDisks |
            Where-Object { $_.DeviceID -eq $driveName } |
            Select-Object -First 1

        if ($null -eq $logicalDisk) {
            $records.Add([pscustomobject]@{
                TimeGenerated          = $collectionTime.ToString('o')
                Computer               = $env:COMPUTERNAME
                Environment            = $sharedSettings.Environment
                Application            = $driveDefinition.Application
                Drive                  = $driveName
                VolumeLabel            = $null
                FileSystem             = $null
                TotalBytes             = [Int64]0
                FreeBytes              = [Int64]0
                UsedBytes              = [Int64]0
                TotalGB                = [double]0
                FreeGB                 = [double]0
                UsedGB                 = [double]0
                FreePercent            = $null
                UsedPercent            = $null
                ReadLatencyMs          = $null
                WriteLatencyMs         = $null
                DiskQueueLength        = $null
                DiskTransfersPerSecond = $null
                CollectionStatus       = 'DriveNotFound'
                CollectorVersion       = '1.0.0'
            })

            $status = 'PartialSuccess'
            continue
        }

        [Int64]$totalBytes = $logicalDisk.Size
        [Int64]$freeBytes = $logicalDisk.FreeSpace
        [Int64]$usedBytes = $totalBytes - $freeBytes

        $freePercent = if ($totalBytes -gt 0) {
            [Math]::Round(($freeBytes / $totalBytes) * 100, 2)
        }
        else {
            $null
        }

        $usedPercent = if ($null -ne $freePercent) {
            [Math]::Round(100 - $freePercent, 2)
        }
        else {
            $null
        }

        $readLatencySeconds = Get-PerformanceValue `
            -PerformanceData $performanceData `
            -Drive $driveName `
            -CounterName 'Avg. Disk sec/Read'

        $writeLatencySeconds = Get-PerformanceValue `
            -PerformanceData $performanceData `
            -Drive $driveName `
            -CounterName 'Avg. Disk sec/Write'

        $queueLength = Get-PerformanceValue `
            -PerformanceData $performanceData `
            -Drive $driveName `
            -CounterName 'Current Disk Queue Length'

        $diskTransfers = Get-PerformanceValue `
            -PerformanceData $performanceData `
            -Drive $driveName `
            -CounterName 'Disk Transfers/sec'

        $performanceAvailable = (
            $null -ne $readLatencySeconds -or
            $null -ne $writeLatencySeconds -or
            $null -ne $queueLength -or
            $null -ne $diskTransfers
        )

        $collectionStatus = if ($performanceAvailable) {
            'Success'
        }
        else {
            'CounterUnavailable'
        }

        if ($collectionStatus -ne 'Success') {
            $status = 'PartialSuccess'
        }

        $records.Add([pscustomobject]@{
            TimeGenerated          = $collectionTime.ToString('o')
            Computer               = $env:COMPUTERNAME
            Environment            = $sharedSettings.Environment
            Application            = $driveDefinition.Application
            Drive                  = $driveName
            VolumeLabel            = $logicalDisk.VolumeName
            FileSystem             = $logicalDisk.FileSystem
            TotalBytes             = $totalBytes
            FreeBytes              = $freeBytes
            UsedBytes              = $usedBytes
            TotalGB                = [Math]::Round($totalBytes / 1GB, 3)
            FreeGB                 = [Math]::Round($freeBytes / 1GB, 3)
            UsedGB                 = [Math]::Round($usedBytes / 1GB, 3)
            FreePercent            = $freePercent
            UsedPercent            = $usedPercent
            ReadLatencyMs          = if ($null -ne $readLatencySeconds) {
                [Math]::Round($readLatencySeconds * 1000, 2)
            } else {
                $null
            }
            WriteLatencyMs         = if ($null -ne $writeLatencySeconds) {
                [Math]::Round($writeLatencySeconds * 1000, 2)
            } else {
                $null
            }
            DiskQueueLength        = if ($null -ne $queueLength) {
                [Math]::Round($queueLength, 2)
            } else {
                $null
            }
            DiskTransfersPerSecond = if ($null -ne $diskTransfers) {
                [Math]::Round($diskTransfers, 2)
            } else {
                $null
            }
            CollectionStatus       = $collectionStatus
            CollectorVersion       = '1.0.0'
        })
    }

    $recordsCollected = $records.Count

    $recordsSubmitted = Send-AzureMonitorRecords `
        -CollectorName $collectorName `
        -IngestionEndpoint $collectorSettings.IngestionEndpoint `
        -DcrImmutableId $collectorSettings.DcrImmutableId `
        -StreamName $collectorSettings.StreamName `
        -Records $records.ToArray() `
        -SharedSettings $sharedSettings `
        -SpoolDirectory $spoolDirectory `
        -LogDirectory $logDirectory `
        -ExecutionId $executionId

    Write-CollectorLog `
        -LogDirectory $logDirectory `
        -Level Information `
        -ExecutionId $executionId `
        -Message (
            "Windows disk metrics completed. Collected=$recordsCollected; " +
            "submitted=$recordsSubmitted."
        )
}
catch {
    $status = 'Failed'
    $errorCode = 'WindowsDiskMetricsFailure'
    $errorMessage = $_.Exception.Message

    Write-CollectorLog `
        -LogDirectory $logDirectory `
        -Level Error `
        -ExecutionId $executionId `
        -Message "Windows disk metrics collector failed. Error: $errorMessage"
}
finally {
    $healthRecord = New-CollectorHealthRecord `
        -CollectorName $collectorName `
        -ExecutionId $executionId `
        -StartedUtc $startedUtc `
        -Status $status `
        -RecordsCollected $recordsCollected `
        -RecordsSubmitted $recordsSubmitted `
        -TargetScope (
            ($collectorSettings.Drives |
                Where-Object { $_.Enabled } |
                ForEach-Object { $_.Drive }) -join ';'
        ) `
        -ErrorCode $errorCode `
        -ErrorMessage $errorMessage `
        -CollectorVersion '1.0.0'

    try {
        Send-AzureMonitorRecords `
            -CollectorName $collectorName `
            -IngestionEndpoint $collectorSettings.HealthIngestionEndpoint `
            -DcrImmutableId $collectorSettings.HealthDcrImmutableId `
            -StreamName $collectorSettings.HealthStreamName `
            -Records @($healthRecord) `
            -SharedSettings $sharedSettings `
            -SpoolDirectory $spoolDirectory `
            -LogDirectory $logDirectory `
            -ExecutionId $executionId | Out-Null
    }
    catch {
        Write-CollectorLog `
            -LogDirectory $logDirectory `
            -Level Error `
            -ExecutionId $executionId `
            -Message (
                "Unable to submit disk collector health record. " +
                "Error: $($_.Exception.Message)"
            )
    }

    if ($null -ne $lockHandle) {
        Exit-CollectorLock -LockHandle $lockHandle -LockPath $lockPath
    }
}

if ($status -eq 'Failed') {
    exit 1
}

exit 0