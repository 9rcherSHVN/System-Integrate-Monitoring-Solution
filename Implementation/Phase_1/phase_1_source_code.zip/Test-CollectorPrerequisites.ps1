[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string] $CollectorRoot,

    [Parameter(Mandatory)]
    [string] $ErpLogPath,

    [switch] $RequireIisBindingDiscovery
)

$failures = [System.Collections.Generic.List[string]]::new()

if ($PSVersionTable.PSVersion.Major -lt 5) {
    $failures.Add('PowerShell 5.1 or later is required.')
}

if (-not (Get-Service -Name 'himds' -ErrorAction SilentlyContinue)) {
    $failures.Add('Azure Arc HIMDS service is not detected. Confirm Azure Arc onboarding.')
}

if ([string]::IsNullOrWhiteSpace($env:IDENTITY_ENDPOINT)) {
    $failures.Add('IDENTITY_ENDPOINT is unavailable. Confirm Azure Arc managed identity.')
}

if (-not (Test-Path -LiteralPath 'Cert:\LocalMachine\WebHosting')) {
    $failures.Add('Certificate store Cert:\LocalMachine\WebHosting is unavailable.')
}

if (-not (Test-Path -LiteralPath $ErpLogPath -PathType Container)) {
    $failures.Add("ERP log directory was not found: $ErpLogPath")
}

if ($RequireIisBindingDiscovery -and
    -not (Get-Module -ListAvailable -Name WebAdministration)) {
    $failures.Add(
        'WebAdministration module is unavailable but IIS binding discovery is enabled.'
    )
}

try {
    New-Item -Path $CollectorRoot -ItemType Directory -Force -ErrorAction Stop | Out-Null
}
catch {
    $failures.Add("Unable to create or access collector root: $CollectorRoot")
}

if ($failures.Count -gt 0) {
    $failures | ForEach-Object { Write-Error $_ }
    exit 1
}

Write-Output 'Collector prerequisite validation succeeded.'
exit 0