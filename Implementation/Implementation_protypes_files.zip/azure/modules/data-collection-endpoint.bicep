@description('Azure region for the Data Collection Endpoint.')
param location string

@description('Data Collection Endpoint name.')
param dceName string

@description('Deployment environment.')
param environment string

resource dce 'Microsoft.Insights/dataCollectionEndpoints@2023-03-11' = {
  name: dceName
  location: location
  tags: {
    Application: 'ERP-Monitoring'
    Environment: environment
    ManagedBy: 'Bicep'
    DataClassification: 'Internal'
    SupportTeam: 'ERP-Platform-Support'
  }
  properties: {
    networkAcls: {
      publicNetworkAccess: 'Enabled'
    }
  }
}

output dataCollectionEndpointResourceId string = dce.id
output logsIngestionEndpoint string = dce.properties.logsIngestion.endpoint