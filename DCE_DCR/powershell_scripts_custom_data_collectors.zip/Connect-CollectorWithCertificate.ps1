param(
    [Parameter(Mandatory)]
    [string] $TenantId,

    [Parameter(Mandatory)]
    [string] $ApplicationId,

    [Parameter(Mandatory)]
    [string] $CertificateThumbprint
)

Import-Module Az.Accounts

Connect-AzAccount `
    -ServicePrincipal `
    -Tenant $TenantId `
    -ApplicationId $ApplicationId `
    -CertificateThumbprint $CertificateThumbprint `
    -ErrorAction Stop | Out-Null